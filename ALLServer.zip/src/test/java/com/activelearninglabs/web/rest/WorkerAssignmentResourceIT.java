package com.activelearninglabs.web.rest;

import com.activelearninglabs.AllServerApp;
import com.activelearninglabs.domain.WorkerAssignment;
import com.activelearninglabs.repository.WorkerAssignmentRepository;
import com.activelearninglabs.web.rest.errors.ExceptionTranslator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.util.List;

import static com.activelearninglabs.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link WorkerAssignmentResource} REST controller.
 */
@SpringBootTest(classes = AllServerApp.class)
public class WorkerAssignmentResourceIT {

    private static final String DEFAULT_STAGE = "AAAAAAAAAA";
    private static final String UPDATED_STAGE = "BBBBBBBBBB";

    private static final String DEFAULT_EMAIL_ID = "AAAAAAAAAA";
    private static final String UPDATED_EMAIL_ID = "BBBBBBBBBB";

    @Autowired
    private WorkerAssignmentRepository workerAssignmentRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restWorkerAssignmentMockMvc;

    private WorkerAssignment workerAssignment;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final WorkerAssignmentResource workerAssignmentResource = new WorkerAssignmentResource(workerAssignmentRepository);
        this.restWorkerAssignmentMockMvc = MockMvcBuilders.standaloneSetup(workerAssignmentResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WorkerAssignment createEntity(EntityManager em) {
        WorkerAssignment workerAssignment = new WorkerAssignment()
            .stage(DEFAULT_STAGE)
            .emailId(DEFAULT_EMAIL_ID);
        return workerAssignment;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WorkerAssignment createUpdatedEntity(EntityManager em) {
        WorkerAssignment workerAssignment = new WorkerAssignment()
            .stage(UPDATED_STAGE)
            .emailId(UPDATED_EMAIL_ID);
        return workerAssignment;
    }

    @BeforeEach
    public void initTest() {
        workerAssignment = createEntity(em);
    }

    @Test
    @Transactional
    public void createWorkerAssignment() throws Exception {
        int databaseSizeBeforeCreate = workerAssignmentRepository.findAll().size();

        // Create the WorkerAssignment
        restWorkerAssignmentMockMvc.perform(post("/api/worker-assignments")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(workerAssignment)))
            .andExpect(status().isCreated());

        // Validate the WorkerAssignment in the database
        List<WorkerAssignment> workerAssignmentList = workerAssignmentRepository.findAll();
        assertThat(workerAssignmentList).hasSize(databaseSizeBeforeCreate + 1);
        WorkerAssignment testWorkerAssignment = workerAssignmentList.get(workerAssignmentList.size() - 1);
        assertThat(testWorkerAssignment.getStage()).isEqualTo(DEFAULT_STAGE);
        assertThat(testWorkerAssignment.getEmailId()).isEqualTo(DEFAULT_EMAIL_ID);
    }

    @Test
    @Transactional
    public void createWorkerAssignmentWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = workerAssignmentRepository.findAll().size();

        // Create the WorkerAssignment with an existing ID
        workerAssignment.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restWorkerAssignmentMockMvc.perform(post("/api/worker-assignments")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(workerAssignment)))
            .andExpect(status().isBadRequest());

        // Validate the WorkerAssignment in the database
        List<WorkerAssignment> workerAssignmentList = workerAssignmentRepository.findAll();
        assertThat(workerAssignmentList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllWorkerAssignments() throws Exception {
        // Initialize the database
        workerAssignmentRepository.saveAndFlush(workerAssignment);

        // Get all the workerAssignmentList
        restWorkerAssignmentMockMvc.perform(get("/api/worker-assignments?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(workerAssignment.getId().intValue())))
            .andExpect(jsonPath("$.[*].stage").value(hasItem(DEFAULT_STAGE.toString())))
            .andExpect(jsonPath("$.[*].emailId").value(hasItem(DEFAULT_EMAIL_ID.toString())));
    }
    
    @Test
    @Transactional
    public void getWorkerAssignment() throws Exception {
        // Initialize the database
        workerAssignmentRepository.saveAndFlush(workerAssignment);

        // Get the workerAssignment
        restWorkerAssignmentMockMvc.perform(get("/api/worker-assignments/{id}", workerAssignment.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(workerAssignment.getId().intValue()))
            .andExpect(jsonPath("$.stage").value(DEFAULT_STAGE.toString()))
            .andExpect(jsonPath("$.emailId").value(DEFAULT_EMAIL_ID.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingWorkerAssignment() throws Exception {
        // Get the workerAssignment
        restWorkerAssignmentMockMvc.perform(get("/api/worker-assignments/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateWorkerAssignment() throws Exception {
        // Initialize the database
        workerAssignmentRepository.saveAndFlush(workerAssignment);

        int databaseSizeBeforeUpdate = workerAssignmentRepository.findAll().size();

        // Update the workerAssignment
        WorkerAssignment updatedWorkerAssignment = workerAssignmentRepository.findById(workerAssignment.getId()).get();
        // Disconnect from session so that the updates on updatedWorkerAssignment are not directly saved in db
        em.detach(updatedWorkerAssignment);
        updatedWorkerAssignment
            .stage(UPDATED_STAGE)
            .emailId(UPDATED_EMAIL_ID);

        restWorkerAssignmentMockMvc.perform(put("/api/worker-assignments")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedWorkerAssignment)))
            .andExpect(status().isOk());

        // Validate the WorkerAssignment in the database
        List<WorkerAssignment> workerAssignmentList = workerAssignmentRepository.findAll();
        assertThat(workerAssignmentList).hasSize(databaseSizeBeforeUpdate);
        WorkerAssignment testWorkerAssignment = workerAssignmentList.get(workerAssignmentList.size() - 1);
        assertThat(testWorkerAssignment.getStage()).isEqualTo(UPDATED_STAGE);
        assertThat(testWorkerAssignment.getEmailId()).isEqualTo(UPDATED_EMAIL_ID);
    }

    @Test
    @Transactional
    public void updateNonExistingWorkerAssignment() throws Exception {
        int databaseSizeBeforeUpdate = workerAssignmentRepository.findAll().size();

        // Create the WorkerAssignment

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restWorkerAssignmentMockMvc.perform(put("/api/worker-assignments")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(workerAssignment)))
            .andExpect(status().isBadRequest());

        // Validate the WorkerAssignment in the database
        List<WorkerAssignment> workerAssignmentList = workerAssignmentRepository.findAll();
        assertThat(workerAssignmentList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteWorkerAssignment() throws Exception {
        // Initialize the database
        workerAssignmentRepository.saveAndFlush(workerAssignment);

        int databaseSizeBeforeDelete = workerAssignmentRepository.findAll().size();

        // Delete the workerAssignment
        restWorkerAssignmentMockMvc.perform(delete("/api/worker-assignments/{id}", workerAssignment.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<WorkerAssignment> workerAssignmentList = workerAssignmentRepository.findAll();
        assertThat(workerAssignmentList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(WorkerAssignment.class);
        WorkerAssignment workerAssignment1 = new WorkerAssignment();
        workerAssignment1.setId(1L);
        WorkerAssignment workerAssignment2 = new WorkerAssignment();
        workerAssignment2.setId(workerAssignment1.getId());
        assertThat(workerAssignment1).isEqualTo(workerAssignment2);
        workerAssignment2.setId(2L);
        assertThat(workerAssignment1).isNotEqualTo(workerAssignment2);
        workerAssignment1.setId(null);
        assertThat(workerAssignment1).isNotEqualTo(workerAssignment2);
    }
}
