package com.activelearninglabs.web.rest;

import com.activelearninglabs.AllServerApp;
import com.activelearninglabs.domain.ActionTopicMapping;
import com.activelearninglabs.repository.ActionTopicMappingRepository;
import com.activelearninglabs.web.rest.errors.ExceptionTranslator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.util.List;

import static com.activelearninglabs.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link ActionTopicMappingResource} REST controller.
 */
@SpringBootTest(classes = AllServerApp.class)
public class ActionTopicMappingResourceIT {

    private static final String DEFAULT_ACTION_NAME = "AAAAAAAAAA";
    private static final String UPDATED_ACTION_NAME = "BBBBBBBBBB";

    @Autowired
    private ActionTopicMappingRepository actionTopicMappingRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restActionTopicMappingMockMvc;

    private ActionTopicMapping actionTopicMapping;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final ActionTopicMappingResource actionTopicMappingResource = new ActionTopicMappingResource(actionTopicMappingRepository);
        this.restActionTopicMappingMockMvc = MockMvcBuilders.standaloneSetup(actionTopicMappingResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static ActionTopicMapping createEntity(EntityManager em) {
        ActionTopicMapping actionTopicMapping = new ActionTopicMapping()
            .actionName(DEFAULT_ACTION_NAME);
        return actionTopicMapping;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static ActionTopicMapping createUpdatedEntity(EntityManager em) {
        ActionTopicMapping actionTopicMapping = new ActionTopicMapping()
            .actionName(UPDATED_ACTION_NAME);
        return actionTopicMapping;
    }

    @BeforeEach
    public void initTest() {
        actionTopicMapping = createEntity(em);
    }

    @Test
    @Transactional
    public void createActionTopicMapping() throws Exception {
        int databaseSizeBeforeCreate = actionTopicMappingRepository.findAll().size();

        // Create the ActionTopicMapping
        restActionTopicMappingMockMvc.perform(post("/api/action-topic-mappings")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(actionTopicMapping)))
            .andExpect(status().isCreated());

        // Validate the ActionTopicMapping in the database
        List<ActionTopicMapping> actionTopicMappingList = actionTopicMappingRepository.findAll();
        assertThat(actionTopicMappingList).hasSize(databaseSizeBeforeCreate + 1);
        ActionTopicMapping testActionTopicMapping = actionTopicMappingList.get(actionTopicMappingList.size() - 1);
        assertThat(testActionTopicMapping.getActionName()).isEqualTo(DEFAULT_ACTION_NAME);
    }

    @Test
    @Transactional
    public void createActionTopicMappingWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = actionTopicMappingRepository.findAll().size();

        // Create the ActionTopicMapping with an existing ID
        actionTopicMapping.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restActionTopicMappingMockMvc.perform(post("/api/action-topic-mappings")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(actionTopicMapping)))
            .andExpect(status().isBadRequest());

        // Validate the ActionTopicMapping in the database
        List<ActionTopicMapping> actionTopicMappingList = actionTopicMappingRepository.findAll();
        assertThat(actionTopicMappingList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllActionTopicMappings() throws Exception {
        // Initialize the database
        actionTopicMappingRepository.saveAndFlush(actionTopicMapping);

        // Get all the actionTopicMappingList
        restActionTopicMappingMockMvc.perform(get("/api/action-topic-mappings?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(actionTopicMapping.getId().intValue())))
            .andExpect(jsonPath("$.[*].actionName").value(hasItem(DEFAULT_ACTION_NAME.toString())));
    }
    
    @Test
    @Transactional
    public void getActionTopicMapping() throws Exception {
        // Initialize the database
        actionTopicMappingRepository.saveAndFlush(actionTopicMapping);

        // Get the actionTopicMapping
        restActionTopicMappingMockMvc.perform(get("/api/action-topic-mappings/{id}", actionTopicMapping.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(actionTopicMapping.getId().intValue()))
            .andExpect(jsonPath("$.actionName").value(DEFAULT_ACTION_NAME.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingActionTopicMapping() throws Exception {
        // Get the actionTopicMapping
        restActionTopicMappingMockMvc.perform(get("/api/action-topic-mappings/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateActionTopicMapping() throws Exception {
        // Initialize the database
        actionTopicMappingRepository.saveAndFlush(actionTopicMapping);

        int databaseSizeBeforeUpdate = actionTopicMappingRepository.findAll().size();

        // Update the actionTopicMapping
        ActionTopicMapping updatedActionTopicMapping = actionTopicMappingRepository.findById(actionTopicMapping.getId()).get();
        // Disconnect from session so that the updates on updatedActionTopicMapping are not directly saved in db
        em.detach(updatedActionTopicMapping);
        updatedActionTopicMapping
            .actionName(UPDATED_ACTION_NAME);

        restActionTopicMappingMockMvc.perform(put("/api/action-topic-mappings")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedActionTopicMapping)))
            .andExpect(status().isOk());

        // Validate the ActionTopicMapping in the database
        List<ActionTopicMapping> actionTopicMappingList = actionTopicMappingRepository.findAll();
        assertThat(actionTopicMappingList).hasSize(databaseSizeBeforeUpdate);
        ActionTopicMapping testActionTopicMapping = actionTopicMappingList.get(actionTopicMappingList.size() - 1);
        assertThat(testActionTopicMapping.getActionName()).isEqualTo(UPDATED_ACTION_NAME);
    }

    @Test
    @Transactional
    public void updateNonExistingActionTopicMapping() throws Exception {
        int databaseSizeBeforeUpdate = actionTopicMappingRepository.findAll().size();

        // Create the ActionTopicMapping

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restActionTopicMappingMockMvc.perform(put("/api/action-topic-mappings")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(actionTopicMapping)))
            .andExpect(status().isBadRequest());

        // Validate the ActionTopicMapping in the database
        List<ActionTopicMapping> actionTopicMappingList = actionTopicMappingRepository.findAll();
        assertThat(actionTopicMappingList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteActionTopicMapping() throws Exception {
        // Initialize the database
        actionTopicMappingRepository.saveAndFlush(actionTopicMapping);

        int databaseSizeBeforeDelete = actionTopicMappingRepository.findAll().size();

        // Delete the actionTopicMapping
        restActionTopicMappingMockMvc.perform(delete("/api/action-topic-mappings/{id}", actionTopicMapping.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<ActionTopicMapping> actionTopicMappingList = actionTopicMappingRepository.findAll();
        assertThat(actionTopicMappingList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(ActionTopicMapping.class);
        ActionTopicMapping actionTopicMapping1 = new ActionTopicMapping();
        actionTopicMapping1.setId(1L);
        ActionTopicMapping actionTopicMapping2 = new ActionTopicMapping();
        actionTopicMapping2.setId(actionTopicMapping1.getId());
        assertThat(actionTopicMapping1).isEqualTo(actionTopicMapping2);
        actionTopicMapping2.setId(2L);
        assertThat(actionTopicMapping1).isNotEqualTo(actionTopicMapping2);
        actionTopicMapping1.setId(null);
        assertThat(actionTopicMapping1).isNotEqualTo(actionTopicMapping2);
    }
}
