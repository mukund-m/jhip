package com.activelearninglabs.web.rest;

import com.activelearninglabs.AllServerApp;
import com.activelearninglabs.domain.ALLUser;
import com.activelearninglabs.repository.ALLUserRepository;
import com.activelearninglabs.web.rest.errors.ExceptionTranslator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.util.List;

import static com.activelearninglabs.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link ALLUserResource} REST controller.
 */
@SpringBootTest(classes = AllServerApp.class)
public class ALLUserResourceIT {

    private static final String DEFAULT_FIRST_NAME = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_LAST_NAME = "AAAAAAAAAA";
    private static final String UPDATED_LAST_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_ROLE = "AAAAAAAAAA";
    private static final String UPDATED_ROLE = "BBBBBBBBBB";

    private static final String DEFAULT_UID = "AAAAAAAAAA";
    private static final String UPDATED_UID = "BBBBBBBBBB";

    private static final String DEFAULT_EMAIL = "AAAAAAAAAA";
    private static final String UPDATED_EMAIL = "BBBBBBBBBB";

    private static final Boolean DEFAULT_ACTIVE = false;
    private static final Boolean UPDATED_ACTIVE = true;

    @Autowired
    private ALLUserRepository aLLUserRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restALLUserMockMvc;

    private ALLUser aLLUser;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final ALLUserResource aLLUserResource = new ALLUserResource(aLLUserRepository);
        this.restALLUserMockMvc = MockMvcBuilders.standaloneSetup(aLLUserResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static ALLUser createEntity(EntityManager em) {
        ALLUser aLLUser = new ALLUser()
            .firstName(DEFAULT_FIRST_NAME)
            .lastName(DEFAULT_LAST_NAME)
            .role(DEFAULT_ROLE)
            .uid(DEFAULT_UID)
            .email(DEFAULT_EMAIL)
            .active(DEFAULT_ACTIVE);
        return aLLUser;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static ALLUser createUpdatedEntity(EntityManager em) {
        ALLUser aLLUser = new ALLUser()
            .firstName(UPDATED_FIRST_NAME)
            .lastName(UPDATED_LAST_NAME)
            .role(UPDATED_ROLE)
            .uid(UPDATED_UID)
            .email(UPDATED_EMAIL)
            .active(UPDATED_ACTIVE);
        return aLLUser;
    }

    @BeforeEach
    public void initTest() {
        aLLUser = createEntity(em);
    }

    @Test
    @Transactional
    public void createALLUser() throws Exception {
        int databaseSizeBeforeCreate = aLLUserRepository.findAll().size();

        // Create the ALLUser
        restALLUserMockMvc.perform(post("/api/all-users")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(aLLUser)))
            .andExpect(status().isCreated());

        // Validate the ALLUser in the database
        List<ALLUser> aLLUserList = aLLUserRepository.findAll();
        assertThat(aLLUserList).hasSize(databaseSizeBeforeCreate + 1);
        ALLUser testALLUser = aLLUserList.get(aLLUserList.size() - 1);
        assertThat(testALLUser.getFirstName()).isEqualTo(DEFAULT_FIRST_NAME);
        assertThat(testALLUser.getLastName()).isEqualTo(DEFAULT_LAST_NAME);
        assertThat(testALLUser.getRole()).isEqualTo(DEFAULT_ROLE);
        assertThat(testALLUser.getUid()).isEqualTo(DEFAULT_UID);
        assertThat(testALLUser.getEmail()).isEqualTo(DEFAULT_EMAIL);
        assertThat(testALLUser.isActive()).isEqualTo(DEFAULT_ACTIVE);
    }

    @Test
    @Transactional
    public void createALLUserWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = aLLUserRepository.findAll().size();

        // Create the ALLUser with an existing ID
        aLLUser.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restALLUserMockMvc.perform(post("/api/all-users")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(aLLUser)))
            .andExpect(status().isBadRequest());

        // Validate the ALLUser in the database
        List<ALLUser> aLLUserList = aLLUserRepository.findAll();
        assertThat(aLLUserList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllALLUsers() throws Exception {
        // Initialize the database
        aLLUserRepository.saveAndFlush(aLLUser);

        // Get all the aLLUserList
        restALLUserMockMvc.perform(get("/api/all-users?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(aLLUser.getId().intValue())))
            .andExpect(jsonPath("$.[*].firstName").value(hasItem(DEFAULT_FIRST_NAME.toString())))
            .andExpect(jsonPath("$.[*].lastName").value(hasItem(DEFAULT_LAST_NAME.toString())))
            .andExpect(jsonPath("$.[*].role").value(hasItem(DEFAULT_ROLE.toString())))
            .andExpect(jsonPath("$.[*].uid").value(hasItem(DEFAULT_UID.toString())))
            .andExpect(jsonPath("$.[*].email").value(hasItem(DEFAULT_EMAIL.toString())))
            .andExpect(jsonPath("$.[*].active").value(hasItem(DEFAULT_ACTIVE.booleanValue())));
    }
    
    @Test
    @Transactional
    public void getALLUser() throws Exception {
        // Initialize the database
        aLLUserRepository.saveAndFlush(aLLUser);

        // Get the aLLUser
        restALLUserMockMvc.perform(get("/api/all-users/{id}", aLLUser.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(aLLUser.getId().intValue()))
            .andExpect(jsonPath("$.firstName").value(DEFAULT_FIRST_NAME.toString()))
            .andExpect(jsonPath("$.lastName").value(DEFAULT_LAST_NAME.toString()))
            .andExpect(jsonPath("$.role").value(DEFAULT_ROLE.toString()))
            .andExpect(jsonPath("$.uid").value(DEFAULT_UID.toString()))
            .andExpect(jsonPath("$.email").value(DEFAULT_EMAIL.toString()))
            .andExpect(jsonPath("$.active").value(DEFAULT_ACTIVE.booleanValue()));
    }

    @Test
    @Transactional
    public void getNonExistingALLUser() throws Exception {
        // Get the aLLUser
        restALLUserMockMvc.perform(get("/api/all-users/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateALLUser() throws Exception {
        // Initialize the database
        aLLUserRepository.saveAndFlush(aLLUser);

        int databaseSizeBeforeUpdate = aLLUserRepository.findAll().size();

        // Update the aLLUser
        ALLUser updatedALLUser = aLLUserRepository.findById(aLLUser.getId()).get();
        // Disconnect from session so that the updates on updatedALLUser are not directly saved in db
        em.detach(updatedALLUser);
        updatedALLUser
            .firstName(UPDATED_FIRST_NAME)
            .lastName(UPDATED_LAST_NAME)
            .role(UPDATED_ROLE)
            .uid(UPDATED_UID)
            .email(UPDATED_EMAIL)
            .active(UPDATED_ACTIVE);

        restALLUserMockMvc.perform(put("/api/all-users")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedALLUser)))
            .andExpect(status().isOk());

        // Validate the ALLUser in the database
        List<ALLUser> aLLUserList = aLLUserRepository.findAll();
        assertThat(aLLUserList).hasSize(databaseSizeBeforeUpdate);
        ALLUser testALLUser = aLLUserList.get(aLLUserList.size() - 1);
        assertThat(testALLUser.getFirstName()).isEqualTo(UPDATED_FIRST_NAME);
        assertThat(testALLUser.getLastName()).isEqualTo(UPDATED_LAST_NAME);
        assertThat(testALLUser.getRole()).isEqualTo(UPDATED_ROLE);
        assertThat(testALLUser.getUid()).isEqualTo(UPDATED_UID);
        assertThat(testALLUser.getEmail()).isEqualTo(UPDATED_EMAIL);
        assertThat(testALLUser.isActive()).isEqualTo(UPDATED_ACTIVE);
    }

    @Test
    @Transactional
    public void updateNonExistingALLUser() throws Exception {
        int databaseSizeBeforeUpdate = aLLUserRepository.findAll().size();

        // Create the ALLUser

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restALLUserMockMvc.perform(put("/api/all-users")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(aLLUser)))
            .andExpect(status().isBadRequest());

        // Validate the ALLUser in the database
        List<ALLUser> aLLUserList = aLLUserRepository.findAll();
        assertThat(aLLUserList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteALLUser() throws Exception {
        // Initialize the database
        aLLUserRepository.saveAndFlush(aLLUser);

        int databaseSizeBeforeDelete = aLLUserRepository.findAll().size();

        // Delete the aLLUser
        restALLUserMockMvc.perform(delete("/api/all-users/{id}", aLLUser.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<ALLUser> aLLUserList = aLLUserRepository.findAll();
        assertThat(aLLUserList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(ALLUser.class);
        ALLUser aLLUser1 = new ALLUser();
        aLLUser1.setId(1L);
        ALLUser aLLUser2 = new ALLUser();
        aLLUser2.setId(aLLUser1.getId());
        assertThat(aLLUser1).isEqualTo(aLLUser2);
        aLLUser2.setId(2L);
        assertThat(aLLUser1).isNotEqualTo(aLLUser2);
        aLLUser1.setId(null);
        assertThat(aLLUser1).isNotEqualTo(aLLUser2);
    }
}
