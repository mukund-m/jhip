package com.activelearninglabs.web.rest;

import com.activelearninglabs.AllServerApp;
import com.activelearninglabs.domain.TeacherAlert;
import com.activelearninglabs.repository.TeacherAlertRepository;
import com.activelearninglabs.web.rest.errors.ExceptionTranslator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.util.List;

import static com.activelearninglabs.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link TeacherAlertResource} REST controller.
 */
@SpringBootTest(classes = AllServerApp.class)
public class TeacherAlertResourceIT {

    private static final String DEFAULT_ALERT_TO = "AAAAAAAAAA";
    private static final String UPDATED_ALERT_TO = "BBBBBBBBBB";

    private static final String DEFAULT_MESSAGE = "AAAAAAAAAA";
    private static final String UPDATED_MESSAGE = "BBBBBBBBBB";

    private static final String DEFAULT_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_TYPE = "BBBBBBBBBB";

    private static final Integer DEFAULT_ALERT_TO_TEAM_ID = 1;
    private static final Integer UPDATED_ALERT_TO_TEAM_ID = 2;
    private static final Integer SMALLER_ALERT_TO_TEAM_ID = 1 - 1;

    private static final Integer DEFAULT_ALERT_TO_USER_ID = 1;
    private static final Integer UPDATED_ALERT_TO_USER_ID = 2;
    private static final Integer SMALLER_ALERT_TO_USER_ID = 1 - 1;

    @Autowired
    private TeacherAlertRepository teacherAlertRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restTeacherAlertMockMvc;

    private TeacherAlert teacherAlert;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final TeacherAlertResource teacherAlertResource = new TeacherAlertResource(teacherAlertRepository);
        this.restTeacherAlertMockMvc = MockMvcBuilders.standaloneSetup(teacherAlertResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TeacherAlert createEntity(EntityManager em) {
        TeacherAlert teacherAlert = new TeacherAlert()
            .alertTo(DEFAULT_ALERT_TO)
            .message(DEFAULT_MESSAGE)
            .type(DEFAULT_TYPE)
            .alertToTeamId(DEFAULT_ALERT_TO_TEAM_ID)
            .alertToUserId(DEFAULT_ALERT_TO_USER_ID);
        return teacherAlert;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TeacherAlert createUpdatedEntity(EntityManager em) {
        TeacherAlert teacherAlert = new TeacherAlert()
            .alertTo(UPDATED_ALERT_TO)
            .message(UPDATED_MESSAGE)
            .type(UPDATED_TYPE)
            .alertToTeamId(UPDATED_ALERT_TO_TEAM_ID)
            .alertToUserId(UPDATED_ALERT_TO_USER_ID);
        return teacherAlert;
    }

    @BeforeEach
    public void initTest() {
        teacherAlert = createEntity(em);
    }

    @Test
    @Transactional
    public void createTeacherAlert() throws Exception {
        int databaseSizeBeforeCreate = teacherAlertRepository.findAll().size();

        // Create the TeacherAlert
        restTeacherAlertMockMvc.perform(post("/api/teacher-alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(teacherAlert)))
            .andExpect(status().isCreated());

        // Validate the TeacherAlert in the database
        List<TeacherAlert> teacherAlertList = teacherAlertRepository.findAll();
        assertThat(teacherAlertList).hasSize(databaseSizeBeforeCreate + 1);
        TeacherAlert testTeacherAlert = teacherAlertList.get(teacherAlertList.size() - 1);
        assertThat(testTeacherAlert.getAlertTo()).isEqualTo(DEFAULT_ALERT_TO);
        assertThat(testTeacherAlert.getMessage()).isEqualTo(DEFAULT_MESSAGE);
        assertThat(testTeacherAlert.getType()).isEqualTo(DEFAULT_TYPE);
        assertThat(testTeacherAlert.getAlertToTeamId()).isEqualTo(DEFAULT_ALERT_TO_TEAM_ID);
        assertThat(testTeacherAlert.getAlertToUserId()).isEqualTo(DEFAULT_ALERT_TO_USER_ID);
    }

    @Test
    @Transactional
    public void createTeacherAlertWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = teacherAlertRepository.findAll().size();

        // Create the TeacherAlert with an existing ID
        teacherAlert.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restTeacherAlertMockMvc.perform(post("/api/teacher-alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(teacherAlert)))
            .andExpect(status().isBadRequest());

        // Validate the TeacherAlert in the database
        List<TeacherAlert> teacherAlertList = teacherAlertRepository.findAll();
        assertThat(teacherAlertList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllTeacherAlerts() throws Exception {
        // Initialize the database
        teacherAlertRepository.saveAndFlush(teacherAlert);

        // Get all the teacherAlertList
        restTeacherAlertMockMvc.perform(get("/api/teacher-alerts?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(teacherAlert.getId().intValue())))
            .andExpect(jsonPath("$.[*].alertTo").value(hasItem(DEFAULT_ALERT_TO.toString())))
            .andExpect(jsonPath("$.[*].message").value(hasItem(DEFAULT_MESSAGE.toString())))
            .andExpect(jsonPath("$.[*].type").value(hasItem(DEFAULT_TYPE.toString())))
            .andExpect(jsonPath("$.[*].alertToTeamId").value(hasItem(DEFAULT_ALERT_TO_TEAM_ID)))
            .andExpect(jsonPath("$.[*].alertToUserId").value(hasItem(DEFAULT_ALERT_TO_USER_ID)));
    }
    
    @Test
    @Transactional
    public void getTeacherAlert() throws Exception {
        // Initialize the database
        teacherAlertRepository.saveAndFlush(teacherAlert);

        // Get the teacherAlert
        restTeacherAlertMockMvc.perform(get("/api/teacher-alerts/{id}", teacherAlert.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(teacherAlert.getId().intValue()))
            .andExpect(jsonPath("$.alertTo").value(DEFAULT_ALERT_TO.toString()))
            .andExpect(jsonPath("$.message").value(DEFAULT_MESSAGE.toString()))
            .andExpect(jsonPath("$.type").value(DEFAULT_TYPE.toString()))
            .andExpect(jsonPath("$.alertToTeamId").value(DEFAULT_ALERT_TO_TEAM_ID))
            .andExpect(jsonPath("$.alertToUserId").value(DEFAULT_ALERT_TO_USER_ID));
    }

    @Test
    @Transactional
    public void getNonExistingTeacherAlert() throws Exception {
        // Get the teacherAlert
        restTeacherAlertMockMvc.perform(get("/api/teacher-alerts/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateTeacherAlert() throws Exception {
        // Initialize the database
        teacherAlertRepository.saveAndFlush(teacherAlert);

        int databaseSizeBeforeUpdate = teacherAlertRepository.findAll().size();

        // Update the teacherAlert
        TeacherAlert updatedTeacherAlert = teacherAlertRepository.findById(teacherAlert.getId()).get();
        // Disconnect from session so that the updates on updatedTeacherAlert are not directly saved in db
        em.detach(updatedTeacherAlert);
        updatedTeacherAlert
            .alertTo(UPDATED_ALERT_TO)
            .message(UPDATED_MESSAGE)
            .type(UPDATED_TYPE)
            .alertToTeamId(UPDATED_ALERT_TO_TEAM_ID)
            .alertToUserId(UPDATED_ALERT_TO_USER_ID);

        restTeacherAlertMockMvc.perform(put("/api/teacher-alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedTeacherAlert)))
            .andExpect(status().isOk());

        // Validate the TeacherAlert in the database
        List<TeacherAlert> teacherAlertList = teacherAlertRepository.findAll();
        assertThat(teacherAlertList).hasSize(databaseSizeBeforeUpdate);
        TeacherAlert testTeacherAlert = teacherAlertList.get(teacherAlertList.size() - 1);
        assertThat(testTeacherAlert.getAlertTo()).isEqualTo(UPDATED_ALERT_TO);
        assertThat(testTeacherAlert.getMessage()).isEqualTo(UPDATED_MESSAGE);
        assertThat(testTeacherAlert.getType()).isEqualTo(UPDATED_TYPE);
        assertThat(testTeacherAlert.getAlertToTeamId()).isEqualTo(UPDATED_ALERT_TO_TEAM_ID);
        assertThat(testTeacherAlert.getAlertToUserId()).isEqualTo(UPDATED_ALERT_TO_USER_ID);
    }

    @Test
    @Transactional
    public void updateNonExistingTeacherAlert() throws Exception {
        int databaseSizeBeforeUpdate = teacherAlertRepository.findAll().size();

        // Create the TeacherAlert

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTeacherAlertMockMvc.perform(put("/api/teacher-alerts")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(teacherAlert)))
            .andExpect(status().isBadRequest());

        // Validate the TeacherAlert in the database
        List<TeacherAlert> teacherAlertList = teacherAlertRepository.findAll();
        assertThat(teacherAlertList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteTeacherAlert() throws Exception {
        // Initialize the database
        teacherAlertRepository.saveAndFlush(teacherAlert);

        int databaseSizeBeforeDelete = teacherAlertRepository.findAll().size();

        // Delete the teacherAlert
        restTeacherAlertMockMvc.perform(delete("/api/teacher-alerts/{id}", teacherAlert.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<TeacherAlert> teacherAlertList = teacherAlertRepository.findAll();
        assertThat(teacherAlertList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(TeacherAlert.class);
        TeacherAlert teacherAlert1 = new TeacherAlert();
        teacherAlert1.setId(1L);
        TeacherAlert teacherAlert2 = new TeacherAlert();
        teacherAlert2.setId(teacherAlert1.getId());
        assertThat(teacherAlert1).isEqualTo(teacherAlert2);
        teacherAlert2.setId(2L);
        assertThat(teacherAlert1).isNotEqualTo(teacherAlert2);
        teacherAlert1.setId(null);
        assertThat(teacherAlert1).isNotEqualTo(teacherAlert2);
    }
}
