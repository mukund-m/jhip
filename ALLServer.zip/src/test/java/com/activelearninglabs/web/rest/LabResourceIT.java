package com.activelearninglabs.web.rest;

import com.activelearninglabs.AllServerApp;
import com.activelearninglabs.domain.Lab;
import com.activelearninglabs.repository.LabRepository;
import com.activelearninglabs.web.rest.errors.ExceptionTranslator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import static com.activelearninglabs.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link LabResource} REST controller.
 */
@SpringBootTest(classes = AllServerApp.class)
public class LabResourceIT {

    private static final LocalDate DEFAULT_BOUGHT_ON = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_BOUGHT_ON = LocalDate.now(ZoneId.systemDefault());
    private static final LocalDate SMALLER_BOUGHT_ON = LocalDate.ofEpochDay(-1L);

    private static final Integer DEFAULT_CURRENT_PHASE = 1;
    private static final Integer UPDATED_CURRENT_PHASE = 2;
    private static final Integer SMALLER_CURRENT_PHASE = 1 - 1;

    private static final LocalDate DEFAULT_LAB_ENDD_DATE = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_LAB_ENDD_DATE = LocalDate.now(ZoneId.systemDefault());
    private static final LocalDate SMALLER_LAB_ENDD_DATE = LocalDate.ofEpochDay(-1L);

    private static final Boolean DEFAULT_SETUP_COMPLETE = false;
    private static final Boolean UPDATED_SETUP_COMPLETE = true;

    private static final Boolean DEFAULT_PHASE_RUNNING = false;
    private static final Boolean UPDATED_PHASE_RUNNING = true;

    private static final Integer DEFAULT_CURRENT_TURN = 1;
    private static final Integer UPDATED_CURRENT_TURN = 2;
    private static final Integer SMALLER_CURRENT_TURN = 1 - 1;

    private static final String DEFAULT_CURRENT_PHASE_CATEGORY = "AAAAAAAAAA";
    private static final String UPDATED_CURRENT_PHASE_CATEGORY = "BBBBBBBBBB";

    private static final Boolean DEFAULT_COMPLETION_COMPLETE = false;
    private static final Boolean UPDATED_COMPLETION_COMPLETE = true;

    @Autowired
    private LabRepository labRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restLabMockMvc;

    private Lab lab;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final LabResource labResource = new LabResource(labRepository);
        this.restLabMockMvc = MockMvcBuilders.standaloneSetup(labResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Lab createEntity(EntityManager em) {
        Lab lab = new Lab()
            .boughtOn(DEFAULT_BOUGHT_ON)
            .currentPhase(DEFAULT_CURRENT_PHASE)
            .labEnddDate(DEFAULT_LAB_ENDD_DATE)
            .setupComplete(DEFAULT_SETUP_COMPLETE)
            .phaseRunning(DEFAULT_PHASE_RUNNING)
            .currentTurn(DEFAULT_CURRENT_TURN)
            .currentPhaseCategory(DEFAULT_CURRENT_PHASE_CATEGORY)
            .completionComplete(DEFAULT_COMPLETION_COMPLETE);
        return lab;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Lab createUpdatedEntity(EntityManager em) {
        Lab lab = new Lab()
            .boughtOn(UPDATED_BOUGHT_ON)
            .currentPhase(UPDATED_CURRENT_PHASE)
            .labEnddDate(UPDATED_LAB_ENDD_DATE)
            .setupComplete(UPDATED_SETUP_COMPLETE)
            .phaseRunning(UPDATED_PHASE_RUNNING)
            .currentTurn(UPDATED_CURRENT_TURN)
            .currentPhaseCategory(UPDATED_CURRENT_PHASE_CATEGORY)
            .completionComplete(UPDATED_COMPLETION_COMPLETE);
        return lab;
    }

    @BeforeEach
    public void initTest() {
        lab = createEntity(em);
    }

    @Test
    @Transactional
    public void createLab() throws Exception {
        int databaseSizeBeforeCreate = labRepository.findAll().size();

        // Create the Lab
        restLabMockMvc.perform(post("/api/labs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(lab)))
            .andExpect(status().isCreated());

        // Validate the Lab in the database
        List<Lab> labList = labRepository.findAll();
        assertThat(labList).hasSize(databaseSizeBeforeCreate + 1);
        Lab testLab = labList.get(labList.size() - 1);
        assertThat(testLab.getBoughtOn()).isEqualTo(DEFAULT_BOUGHT_ON);
        assertThat(testLab.getCurrentPhase()).isEqualTo(DEFAULT_CURRENT_PHASE);
        assertThat(testLab.getLabEnddDate()).isEqualTo(DEFAULT_LAB_ENDD_DATE);
        assertThat(testLab.isSetupComplete()).isEqualTo(DEFAULT_SETUP_COMPLETE);
        assertThat(testLab.isPhaseRunning()).isEqualTo(DEFAULT_PHASE_RUNNING);
        assertThat(testLab.getCurrentTurn()).isEqualTo(DEFAULT_CURRENT_TURN);
        assertThat(testLab.getCurrentPhaseCategory()).isEqualTo(DEFAULT_CURRENT_PHASE_CATEGORY);
        assertThat(testLab.isCompletionComplete()).isEqualTo(DEFAULT_COMPLETION_COMPLETE);
    }

    @Test
    @Transactional
    public void createLabWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = labRepository.findAll().size();

        // Create the Lab with an existing ID
        lab.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restLabMockMvc.perform(post("/api/labs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(lab)))
            .andExpect(status().isBadRequest());

        // Validate the Lab in the database
        List<Lab> labList = labRepository.findAll();
        assertThat(labList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllLabs() throws Exception {
        // Initialize the database
        labRepository.saveAndFlush(lab);

        // Get all the labList
        restLabMockMvc.perform(get("/api/labs?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(lab.getId().intValue())))
            .andExpect(jsonPath("$.[*].boughtOn").value(hasItem(DEFAULT_BOUGHT_ON.toString())))
            .andExpect(jsonPath("$.[*].currentPhase").value(hasItem(DEFAULT_CURRENT_PHASE)))
            .andExpect(jsonPath("$.[*].labEnddDate").value(hasItem(DEFAULT_LAB_ENDD_DATE.toString())))
            .andExpect(jsonPath("$.[*].setupComplete").value(hasItem(DEFAULT_SETUP_COMPLETE.booleanValue())))
            .andExpect(jsonPath("$.[*].phaseRunning").value(hasItem(DEFAULT_PHASE_RUNNING.booleanValue())))
            .andExpect(jsonPath("$.[*].currentTurn").value(hasItem(DEFAULT_CURRENT_TURN)))
            .andExpect(jsonPath("$.[*].currentPhaseCategory").value(hasItem(DEFAULT_CURRENT_PHASE_CATEGORY.toString())))
            .andExpect(jsonPath("$.[*].completionComplete").value(hasItem(DEFAULT_COMPLETION_COMPLETE.booleanValue())));
    }
    
    @Test
    @Transactional
    public void getLab() throws Exception {
        // Initialize the database
        labRepository.saveAndFlush(lab);

        // Get the lab
        restLabMockMvc.perform(get("/api/labs/{id}", lab.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(lab.getId().intValue()))
            .andExpect(jsonPath("$.boughtOn").value(DEFAULT_BOUGHT_ON.toString()))
            .andExpect(jsonPath("$.currentPhase").value(DEFAULT_CURRENT_PHASE))
            .andExpect(jsonPath("$.labEnddDate").value(DEFAULT_LAB_ENDD_DATE.toString()))
            .andExpect(jsonPath("$.setupComplete").value(DEFAULT_SETUP_COMPLETE.booleanValue()))
            .andExpect(jsonPath("$.phaseRunning").value(DEFAULT_PHASE_RUNNING.booleanValue()))
            .andExpect(jsonPath("$.currentTurn").value(DEFAULT_CURRENT_TURN))
            .andExpect(jsonPath("$.currentPhaseCategory").value(DEFAULT_CURRENT_PHASE_CATEGORY.toString()))
            .andExpect(jsonPath("$.completionComplete").value(DEFAULT_COMPLETION_COMPLETE.booleanValue()));
    }

    @Test
    @Transactional
    public void getNonExistingLab() throws Exception {
        // Get the lab
        restLabMockMvc.perform(get("/api/labs/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateLab() throws Exception {
        // Initialize the database
        labRepository.saveAndFlush(lab);

        int databaseSizeBeforeUpdate = labRepository.findAll().size();

        // Update the lab
        Lab updatedLab = labRepository.findById(lab.getId()).get();
        // Disconnect from session so that the updates on updatedLab are not directly saved in db
        em.detach(updatedLab);
        updatedLab
            .boughtOn(UPDATED_BOUGHT_ON)
            .currentPhase(UPDATED_CURRENT_PHASE)
            .labEnddDate(UPDATED_LAB_ENDD_DATE)
            .setupComplete(UPDATED_SETUP_COMPLETE)
            .phaseRunning(UPDATED_PHASE_RUNNING)
            .currentTurn(UPDATED_CURRENT_TURN)
            .currentPhaseCategory(UPDATED_CURRENT_PHASE_CATEGORY)
            .completionComplete(UPDATED_COMPLETION_COMPLETE);

        restLabMockMvc.perform(put("/api/labs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedLab)))
            .andExpect(status().isOk());

        // Validate the Lab in the database
        List<Lab> labList = labRepository.findAll();
        assertThat(labList).hasSize(databaseSizeBeforeUpdate);
        Lab testLab = labList.get(labList.size() - 1);
        assertThat(testLab.getBoughtOn()).isEqualTo(UPDATED_BOUGHT_ON);
        assertThat(testLab.getCurrentPhase()).isEqualTo(UPDATED_CURRENT_PHASE);
        assertThat(testLab.getLabEnddDate()).isEqualTo(UPDATED_LAB_ENDD_DATE);
        assertThat(testLab.isSetupComplete()).isEqualTo(UPDATED_SETUP_COMPLETE);
        assertThat(testLab.isPhaseRunning()).isEqualTo(UPDATED_PHASE_RUNNING);
        assertThat(testLab.getCurrentTurn()).isEqualTo(UPDATED_CURRENT_TURN);
        assertThat(testLab.getCurrentPhaseCategory()).isEqualTo(UPDATED_CURRENT_PHASE_CATEGORY);
        assertThat(testLab.isCompletionComplete()).isEqualTo(UPDATED_COMPLETION_COMPLETE);
    }

    @Test
    @Transactional
    public void updateNonExistingLab() throws Exception {
        int databaseSizeBeforeUpdate = labRepository.findAll().size();

        // Create the Lab

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restLabMockMvc.perform(put("/api/labs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(lab)))
            .andExpect(status().isBadRequest());

        // Validate the Lab in the database
        List<Lab> labList = labRepository.findAll();
        assertThat(labList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteLab() throws Exception {
        // Initialize the database
        labRepository.saveAndFlush(lab);

        int databaseSizeBeforeDelete = labRepository.findAll().size();

        // Delete the lab
        restLabMockMvc.perform(delete("/api/labs/{id}", lab.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<Lab> labList = labRepository.findAll();
        assertThat(labList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Lab.class);
        Lab lab1 = new Lab();
        lab1.setId(1L);
        Lab lab2 = new Lab();
        lab2.setId(lab1.getId());
        assertThat(lab1).isEqualTo(lab2);
        lab2.setId(2L);
        assertThat(lab1).isNotEqualTo(lab2);
        lab1.setId(null);
        assertThat(lab1).isNotEqualTo(lab2);
    }
}
