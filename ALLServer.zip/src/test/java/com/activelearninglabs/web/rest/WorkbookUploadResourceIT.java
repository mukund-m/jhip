package com.activelearninglabs.web.rest;

import com.activelearninglabs.AllServerApp;
import com.activelearninglabs.domain.WorkbookUpload;
import com.activelearninglabs.repository.WorkbookUploadRepository;
import com.activelearninglabs.web.rest.errors.ExceptionTranslator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.util.List;

import static com.activelearninglabs.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link WorkbookUploadResource} REST controller.
 */
@SpringBootTest(classes = AllServerApp.class)
public class WorkbookUploadResourceIT {

    private static final String DEFAULT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_DESCRIPTION = "AAAAAAAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBBBBBBB";

    private static final String DEFAULT_URL = "AAAAAAAAAA";
    private static final String UPDATED_URL = "BBBBBBBBBB";

    private static final String DEFAULT_SHEET_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_SHEET_TYPE = "BBBBBBBBBB";

    private static final String DEFAULT_DIFFICULTY = "AAAAAAAAAA";
    private static final String UPDATED_DIFFICULTY = "BBBBBBBBBB";

    @Autowired
    private WorkbookUploadRepository workbookUploadRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restWorkbookUploadMockMvc;

    private WorkbookUpload workbookUpload;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final WorkbookUploadResource workbookUploadResource = new WorkbookUploadResource(workbookUploadRepository);
        this.restWorkbookUploadMockMvc = MockMvcBuilders.standaloneSetup(workbookUploadResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WorkbookUpload createEntity(EntityManager em) {
        WorkbookUpload workbookUpload = new WorkbookUpload()
            .name(DEFAULT_NAME)
            .description(DEFAULT_DESCRIPTION)
            .url(DEFAULT_URL)
            .sheetType(DEFAULT_SHEET_TYPE)
            .difficulty(DEFAULT_DIFFICULTY);
        return workbookUpload;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WorkbookUpload createUpdatedEntity(EntityManager em) {
        WorkbookUpload workbookUpload = new WorkbookUpload()
            .name(UPDATED_NAME)
            .description(UPDATED_DESCRIPTION)
            .url(UPDATED_URL)
            .sheetType(UPDATED_SHEET_TYPE)
            .difficulty(UPDATED_DIFFICULTY);
        return workbookUpload;
    }

    @BeforeEach
    public void initTest() {
        workbookUpload = createEntity(em);
    }

    @Test
    @Transactional
    public void createWorkbookUpload() throws Exception {
        int databaseSizeBeforeCreate = workbookUploadRepository.findAll().size();

        // Create the WorkbookUpload
        restWorkbookUploadMockMvc.perform(post("/api/workbook-uploads")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(workbookUpload)))
            .andExpect(status().isCreated());

        // Validate the WorkbookUpload in the database
        List<WorkbookUpload> workbookUploadList = workbookUploadRepository.findAll();
        assertThat(workbookUploadList).hasSize(databaseSizeBeforeCreate + 1);
        WorkbookUpload testWorkbookUpload = workbookUploadList.get(workbookUploadList.size() - 1);
        assertThat(testWorkbookUpload.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testWorkbookUpload.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testWorkbookUpload.getUrl()).isEqualTo(DEFAULT_URL);
        assertThat(testWorkbookUpload.getSheetType()).isEqualTo(DEFAULT_SHEET_TYPE);
        assertThat(testWorkbookUpload.getDifficulty()).isEqualTo(DEFAULT_DIFFICULTY);
    }

    @Test
    @Transactional
    public void createWorkbookUploadWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = workbookUploadRepository.findAll().size();

        // Create the WorkbookUpload with an existing ID
        workbookUpload.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restWorkbookUploadMockMvc.perform(post("/api/workbook-uploads")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(workbookUpload)))
            .andExpect(status().isBadRequest());

        // Validate the WorkbookUpload in the database
        List<WorkbookUpload> workbookUploadList = workbookUploadRepository.findAll();
        assertThat(workbookUploadList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllWorkbookUploads() throws Exception {
        // Initialize the database
        workbookUploadRepository.saveAndFlush(workbookUpload);

        // Get all the workbookUploadList
        restWorkbookUploadMockMvc.perform(get("/api/workbook-uploads?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(workbookUpload.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].url").value(hasItem(DEFAULT_URL.toString())))
            .andExpect(jsonPath("$.[*].sheetType").value(hasItem(DEFAULT_SHEET_TYPE.toString())))
            .andExpect(jsonPath("$.[*].difficulty").value(hasItem(DEFAULT_DIFFICULTY.toString())));
    }
    
    @Test
    @Transactional
    public void getWorkbookUpload() throws Exception {
        // Initialize the database
        workbookUploadRepository.saveAndFlush(workbookUpload);

        // Get the workbookUpload
        restWorkbookUploadMockMvc.perform(get("/api/workbook-uploads/{id}", workbookUpload.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(workbookUpload.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.url").value(DEFAULT_URL.toString()))
            .andExpect(jsonPath("$.sheetType").value(DEFAULT_SHEET_TYPE.toString()))
            .andExpect(jsonPath("$.difficulty").value(DEFAULT_DIFFICULTY.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingWorkbookUpload() throws Exception {
        // Get the workbookUpload
        restWorkbookUploadMockMvc.perform(get("/api/workbook-uploads/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateWorkbookUpload() throws Exception {
        // Initialize the database
        workbookUploadRepository.saveAndFlush(workbookUpload);

        int databaseSizeBeforeUpdate = workbookUploadRepository.findAll().size();

        // Update the workbookUpload
        WorkbookUpload updatedWorkbookUpload = workbookUploadRepository.findById(workbookUpload.getId()).get();
        // Disconnect from session so that the updates on updatedWorkbookUpload are not directly saved in db
        em.detach(updatedWorkbookUpload);
        updatedWorkbookUpload
            .name(UPDATED_NAME)
            .description(UPDATED_DESCRIPTION)
            .url(UPDATED_URL)
            .sheetType(UPDATED_SHEET_TYPE)
            .difficulty(UPDATED_DIFFICULTY);

        restWorkbookUploadMockMvc.perform(put("/api/workbook-uploads")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedWorkbookUpload)))
            .andExpect(status().isOk());

        // Validate the WorkbookUpload in the database
        List<WorkbookUpload> workbookUploadList = workbookUploadRepository.findAll();
        assertThat(workbookUploadList).hasSize(databaseSizeBeforeUpdate);
        WorkbookUpload testWorkbookUpload = workbookUploadList.get(workbookUploadList.size() - 1);
        assertThat(testWorkbookUpload.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testWorkbookUpload.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testWorkbookUpload.getUrl()).isEqualTo(UPDATED_URL);
        assertThat(testWorkbookUpload.getSheetType()).isEqualTo(UPDATED_SHEET_TYPE);
        assertThat(testWorkbookUpload.getDifficulty()).isEqualTo(UPDATED_DIFFICULTY);
    }

    @Test
    @Transactional
    public void updateNonExistingWorkbookUpload() throws Exception {
        int databaseSizeBeforeUpdate = workbookUploadRepository.findAll().size();

        // Create the WorkbookUpload

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restWorkbookUploadMockMvc.perform(put("/api/workbook-uploads")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(workbookUpload)))
            .andExpect(status().isBadRequest());

        // Validate the WorkbookUpload in the database
        List<WorkbookUpload> workbookUploadList = workbookUploadRepository.findAll();
        assertThat(workbookUploadList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteWorkbookUpload() throws Exception {
        // Initialize the database
        workbookUploadRepository.saveAndFlush(workbookUpload);

        int databaseSizeBeforeDelete = workbookUploadRepository.findAll().size();

        // Delete the workbookUpload
        restWorkbookUploadMockMvc.perform(delete("/api/workbook-uploads/{id}", workbookUpload.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<WorkbookUpload> workbookUploadList = workbookUploadRepository.findAll();
        assertThat(workbookUploadList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(WorkbookUpload.class);
        WorkbookUpload workbookUpload1 = new WorkbookUpload();
        workbookUpload1.setId(1L);
        WorkbookUpload workbookUpload2 = new WorkbookUpload();
        workbookUpload2.setId(workbookUpload1.getId());
        assertThat(workbookUpload1).isEqualTo(workbookUpload2);
        workbookUpload2.setId(2L);
        assertThat(workbookUpload1).isNotEqualTo(workbookUpload2);
        workbookUpload1.setId(null);
        assertThat(workbookUpload1).isNotEqualTo(workbookUpload2);
    }
}
