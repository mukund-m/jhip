package com.activelearninglabs.web.rest;

import com.activelearninglabs.AllServerApp;
import com.activelearninglabs.domain.StageSubmission;
import com.activelearninglabs.repository.StageSubmissionRepository;
import com.activelearninglabs.web.rest.errors.ExceptionTranslator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import static com.activelearninglabs.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link StageSubmissionResource} REST controller.
 */
@SpringBootTest(classes = AllServerApp.class)
public class StageSubmissionResourceIT {

    private static final LocalDate DEFAULT_SUBMITTED_DATE = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_SUBMITTED_DATE = LocalDate.now(ZoneId.systemDefault());
    private static final LocalDate SMALLER_SUBMITTED_DATE = LocalDate.ofEpochDay(-1L);

    private static final String DEFAULT_SHEET_NAME = "AAAAAAAAAA";
    private static final String UPDATED_SHEET_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_SHEET_CATEGORY = "AAAAAAAAAA";
    private static final String UPDATED_SHEET_CATEGORY = "BBBBBBBBBB";

    private static final Integer DEFAULT_STAGE_NUM = 1;
    private static final Integer UPDATED_STAGE_NUM = 2;
    private static final Integer SMALLER_STAGE_NUM = 1 - 1;

    private static final Integer DEFAULT_TURN_NUM = 1;
    private static final Integer UPDATED_TURN_NUM = 2;
    private static final Integer SMALLER_TURN_NUM = 1 - 1;

    @Autowired
    private StageSubmissionRepository stageSubmissionRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restStageSubmissionMockMvc;

    private StageSubmission stageSubmission;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final StageSubmissionResource stageSubmissionResource = new StageSubmissionResource(stageSubmissionRepository);
        this.restStageSubmissionMockMvc = MockMvcBuilders.standaloneSetup(stageSubmissionResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static StageSubmission createEntity(EntityManager em) {
        StageSubmission stageSubmission = new StageSubmission()
            .submittedDate(DEFAULT_SUBMITTED_DATE)
            .sheetName(DEFAULT_SHEET_NAME)
            .sheetCategory(DEFAULT_SHEET_CATEGORY)
            .stageNum(DEFAULT_STAGE_NUM)
            .turnNum(DEFAULT_TURN_NUM);
        return stageSubmission;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static StageSubmission createUpdatedEntity(EntityManager em) {
        StageSubmission stageSubmission = new StageSubmission()
            .submittedDate(UPDATED_SUBMITTED_DATE)
            .sheetName(UPDATED_SHEET_NAME)
            .sheetCategory(UPDATED_SHEET_CATEGORY)
            .stageNum(UPDATED_STAGE_NUM)
            .turnNum(UPDATED_TURN_NUM);
        return stageSubmission;
    }

    @BeforeEach
    public void initTest() {
        stageSubmission = createEntity(em);
    }

    @Test
    @Transactional
    public void createStageSubmission() throws Exception {
        int databaseSizeBeforeCreate = stageSubmissionRepository.findAll().size();

        // Create the StageSubmission
        restStageSubmissionMockMvc.perform(post("/api/stage-submissions")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(stageSubmission)))
            .andExpect(status().isCreated());

        // Validate the StageSubmission in the database
        List<StageSubmission> stageSubmissionList = stageSubmissionRepository.findAll();
        assertThat(stageSubmissionList).hasSize(databaseSizeBeforeCreate + 1);
        StageSubmission testStageSubmission = stageSubmissionList.get(stageSubmissionList.size() - 1);
        assertThat(testStageSubmission.getSubmittedDate()).isEqualTo(DEFAULT_SUBMITTED_DATE);
        assertThat(testStageSubmission.getSheetName()).isEqualTo(DEFAULT_SHEET_NAME);
        assertThat(testStageSubmission.getSheetCategory()).isEqualTo(DEFAULT_SHEET_CATEGORY);
        assertThat(testStageSubmission.getStageNum()).isEqualTo(DEFAULT_STAGE_NUM);
        assertThat(testStageSubmission.getTurnNum()).isEqualTo(DEFAULT_TURN_NUM);
    }

    @Test
    @Transactional
    public void createStageSubmissionWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = stageSubmissionRepository.findAll().size();

        // Create the StageSubmission with an existing ID
        stageSubmission.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restStageSubmissionMockMvc.perform(post("/api/stage-submissions")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(stageSubmission)))
            .andExpect(status().isBadRequest());

        // Validate the StageSubmission in the database
        List<StageSubmission> stageSubmissionList = stageSubmissionRepository.findAll();
        assertThat(stageSubmissionList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllStageSubmissions() throws Exception {
        // Initialize the database
        stageSubmissionRepository.saveAndFlush(stageSubmission);

        // Get all the stageSubmissionList
        restStageSubmissionMockMvc.perform(get("/api/stage-submissions?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(stageSubmission.getId().intValue())))
            .andExpect(jsonPath("$.[*].submittedDate").value(hasItem(DEFAULT_SUBMITTED_DATE.toString())))
            .andExpect(jsonPath("$.[*].sheetName").value(hasItem(DEFAULT_SHEET_NAME.toString())))
            .andExpect(jsonPath("$.[*].sheetCategory").value(hasItem(DEFAULT_SHEET_CATEGORY.toString())))
            .andExpect(jsonPath("$.[*].stageNum").value(hasItem(DEFAULT_STAGE_NUM)))
            .andExpect(jsonPath("$.[*].turnNum").value(hasItem(DEFAULT_TURN_NUM)));
    }
    
    @Test
    @Transactional
    public void getStageSubmission() throws Exception {
        // Initialize the database
        stageSubmissionRepository.saveAndFlush(stageSubmission);

        // Get the stageSubmission
        restStageSubmissionMockMvc.perform(get("/api/stage-submissions/{id}", stageSubmission.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(stageSubmission.getId().intValue()))
            .andExpect(jsonPath("$.submittedDate").value(DEFAULT_SUBMITTED_DATE.toString()))
            .andExpect(jsonPath("$.sheetName").value(DEFAULT_SHEET_NAME.toString()))
            .andExpect(jsonPath("$.sheetCategory").value(DEFAULT_SHEET_CATEGORY.toString()))
            .andExpect(jsonPath("$.stageNum").value(DEFAULT_STAGE_NUM))
            .andExpect(jsonPath("$.turnNum").value(DEFAULT_TURN_NUM));
    }

    @Test
    @Transactional
    public void getNonExistingStageSubmission() throws Exception {
        // Get the stageSubmission
        restStageSubmissionMockMvc.perform(get("/api/stage-submissions/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateStageSubmission() throws Exception {
        // Initialize the database
        stageSubmissionRepository.saveAndFlush(stageSubmission);

        int databaseSizeBeforeUpdate = stageSubmissionRepository.findAll().size();

        // Update the stageSubmission
        StageSubmission updatedStageSubmission = stageSubmissionRepository.findById(stageSubmission.getId()).get();
        // Disconnect from session so that the updates on updatedStageSubmission are not directly saved in db
        em.detach(updatedStageSubmission);
        updatedStageSubmission
            .submittedDate(UPDATED_SUBMITTED_DATE)
            .sheetName(UPDATED_SHEET_NAME)
            .sheetCategory(UPDATED_SHEET_CATEGORY)
            .stageNum(UPDATED_STAGE_NUM)
            .turnNum(UPDATED_TURN_NUM);

        restStageSubmissionMockMvc.perform(put("/api/stage-submissions")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedStageSubmission)))
            .andExpect(status().isOk());

        // Validate the StageSubmission in the database
        List<StageSubmission> stageSubmissionList = stageSubmissionRepository.findAll();
        assertThat(stageSubmissionList).hasSize(databaseSizeBeforeUpdate);
        StageSubmission testStageSubmission = stageSubmissionList.get(stageSubmissionList.size() - 1);
        assertThat(testStageSubmission.getSubmittedDate()).isEqualTo(UPDATED_SUBMITTED_DATE);
        assertThat(testStageSubmission.getSheetName()).isEqualTo(UPDATED_SHEET_NAME);
        assertThat(testStageSubmission.getSheetCategory()).isEqualTo(UPDATED_SHEET_CATEGORY);
        assertThat(testStageSubmission.getStageNum()).isEqualTo(UPDATED_STAGE_NUM);
        assertThat(testStageSubmission.getTurnNum()).isEqualTo(UPDATED_TURN_NUM);
    }

    @Test
    @Transactional
    public void updateNonExistingStageSubmission() throws Exception {
        int databaseSizeBeforeUpdate = stageSubmissionRepository.findAll().size();

        // Create the StageSubmission

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restStageSubmissionMockMvc.perform(put("/api/stage-submissions")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(stageSubmission)))
            .andExpect(status().isBadRequest());

        // Validate the StageSubmission in the database
        List<StageSubmission> stageSubmissionList = stageSubmissionRepository.findAll();
        assertThat(stageSubmissionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteStageSubmission() throws Exception {
        // Initialize the database
        stageSubmissionRepository.saveAndFlush(stageSubmission);

        int databaseSizeBeforeDelete = stageSubmissionRepository.findAll().size();

        // Delete the stageSubmission
        restStageSubmissionMockMvc.perform(delete("/api/stage-submissions/{id}", stageSubmission.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<StageSubmission> stageSubmissionList = stageSubmissionRepository.findAll();
        assertThat(stageSubmissionList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(StageSubmission.class);
        StageSubmission stageSubmission1 = new StageSubmission();
        stageSubmission1.setId(1L);
        StageSubmission stageSubmission2 = new StageSubmission();
        stageSubmission2.setId(stageSubmission1.getId());
        assertThat(stageSubmission1).isEqualTo(stageSubmission2);
        stageSubmission2.setId(2L);
        assertThat(stageSubmission1).isNotEqualTo(stageSubmission2);
        stageSubmission1.setId(null);
        assertThat(stageSubmission1).isNotEqualTo(stageSubmission2);
    }
}
