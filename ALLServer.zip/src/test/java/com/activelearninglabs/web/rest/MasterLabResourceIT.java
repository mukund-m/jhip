package com.activelearninglabs.web.rest;

import com.activelearninglabs.AllServerApp;
import com.activelearninglabs.domain.MasterLab;
import com.activelearninglabs.repository.MasterLabRepository;
import com.activelearninglabs.web.rest.errors.ExceptionTranslator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Base64Utils;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.util.List;

import static com.activelearninglabs.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link MasterLabResource} REST controller.
 */
@SpringBootTest(classes = AllServerApp.class)
public class MasterLabResourceIT {

    private static final String DEFAULT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_DESCRIPTION = "AAAAAAAAAA";
    private static final String UPDATED_DESCRIPTION = "BBBBBBBBBB";

    private static final String DEFAULT_SCHOOL_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_SCHOOL_TYPE = "BBBBBBBBBB";

    private static final String DEFAULT_CATEGORY = "AAAAAAAAAA";
    private static final String UPDATED_CATEGORY = "BBBBBBBBBB";

    private static final Boolean DEFAULT_SINGLE_USER_MODE = false;
    private static final Boolean UPDATED_SINGLE_USER_MODE = true;

    private static final String DEFAULT_SPREAD_SHEET_ID = "AAAAAAAAAA";
    private static final String UPDATED_SPREAD_SHEET_ID = "BBBBBBBBBB";

    private static final byte[] DEFAULT_METADATA = TestUtil.createByteArray(1, "0");
    private static final byte[] UPDATED_METADATA = TestUtil.createByteArray(1, "1");
    private static final String DEFAULT_METADATA_CONTENT_TYPE = "image/jpg";
    private static final String UPDATED_METADATA_CONTENT_TYPE = "image/png";

    @Autowired
    private MasterLabRepository masterLabRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restMasterLabMockMvc;

    private MasterLab masterLab;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final MasterLabResource masterLabResource = new MasterLabResource(masterLabRepository);
        this.restMasterLabMockMvc = MockMvcBuilders.standaloneSetup(masterLabResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static MasterLab createEntity(EntityManager em) {
        MasterLab masterLab = new MasterLab()
            .name(DEFAULT_NAME)
            .description(DEFAULT_DESCRIPTION)
            .schoolType(DEFAULT_SCHOOL_TYPE)
            .category(DEFAULT_CATEGORY)
            .singleUserMode(DEFAULT_SINGLE_USER_MODE)
            .spreadSheetId(DEFAULT_SPREAD_SHEET_ID)
            .metadata(DEFAULT_METADATA)
            .metadataContentType(DEFAULT_METADATA_CONTENT_TYPE);
        return masterLab;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static MasterLab createUpdatedEntity(EntityManager em) {
        MasterLab masterLab = new MasterLab()
            .name(UPDATED_NAME)
            .description(UPDATED_DESCRIPTION)
            .schoolType(UPDATED_SCHOOL_TYPE)
            .category(UPDATED_CATEGORY)
            .singleUserMode(UPDATED_SINGLE_USER_MODE)
            .spreadSheetId(UPDATED_SPREAD_SHEET_ID)
            .metadata(UPDATED_METADATA)
            .metadataContentType(UPDATED_METADATA_CONTENT_TYPE);
        return masterLab;
    }

    @BeforeEach
    public void initTest() {
        masterLab = createEntity(em);
    }

    @Test
    @Transactional
    public void createMasterLab() throws Exception {
        int databaseSizeBeforeCreate = masterLabRepository.findAll().size();

        // Create the MasterLab
        restMasterLabMockMvc.perform(post("/api/master-labs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(masterLab)))
            .andExpect(status().isCreated());

        // Validate the MasterLab in the database
        List<MasterLab> masterLabList = masterLabRepository.findAll();
        assertThat(masterLabList).hasSize(databaseSizeBeforeCreate + 1);
        MasterLab testMasterLab = masterLabList.get(masterLabList.size() - 1);
        assertThat(testMasterLab.getName()).isEqualTo(DEFAULT_NAME);
        assertThat(testMasterLab.getDescription()).isEqualTo(DEFAULT_DESCRIPTION);
        assertThat(testMasterLab.getSchoolType()).isEqualTo(DEFAULT_SCHOOL_TYPE);
        assertThat(testMasterLab.getCategory()).isEqualTo(DEFAULT_CATEGORY);
        assertThat(testMasterLab.isSingleUserMode()).isEqualTo(DEFAULT_SINGLE_USER_MODE);
        assertThat(testMasterLab.getSpreadSheetId()).isEqualTo(DEFAULT_SPREAD_SHEET_ID);
        assertThat(testMasterLab.getMetadata()).isEqualTo(DEFAULT_METADATA);
        assertThat(testMasterLab.getMetadataContentType()).isEqualTo(DEFAULT_METADATA_CONTENT_TYPE);
    }

    @Test
    @Transactional
    public void createMasterLabWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = masterLabRepository.findAll().size();

        // Create the MasterLab with an existing ID
        masterLab.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restMasterLabMockMvc.perform(post("/api/master-labs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(masterLab)))
            .andExpect(status().isBadRequest());

        // Validate the MasterLab in the database
        List<MasterLab> masterLabList = masterLabRepository.findAll();
        assertThat(masterLabList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllMasterLabs() throws Exception {
        // Initialize the database
        masterLabRepository.saveAndFlush(masterLab);

        // Get all the masterLabList
        restMasterLabMockMvc.perform(get("/api/master-labs?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(masterLab.getId().intValue())))
            .andExpect(jsonPath("$.[*].name").value(hasItem(DEFAULT_NAME.toString())))
            .andExpect(jsonPath("$.[*].description").value(hasItem(DEFAULT_DESCRIPTION.toString())))
            .andExpect(jsonPath("$.[*].schoolType").value(hasItem(DEFAULT_SCHOOL_TYPE.toString())))
            .andExpect(jsonPath("$.[*].category").value(hasItem(DEFAULT_CATEGORY.toString())))
            .andExpect(jsonPath("$.[*].singleUserMode").value(hasItem(DEFAULT_SINGLE_USER_MODE.booleanValue())))
            .andExpect(jsonPath("$.[*].spreadSheetId").value(hasItem(DEFAULT_SPREAD_SHEET_ID.toString())))
            .andExpect(jsonPath("$.[*].metadataContentType").value(hasItem(DEFAULT_METADATA_CONTENT_TYPE)))
            .andExpect(jsonPath("$.[*].metadata").value(hasItem(Base64Utils.encodeToString(DEFAULT_METADATA))));
    }
    
    @Test
    @Transactional
    public void getMasterLab() throws Exception {
        // Initialize the database
        masterLabRepository.saveAndFlush(masterLab);

        // Get the masterLab
        restMasterLabMockMvc.perform(get("/api/master-labs/{id}", masterLab.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(masterLab.getId().intValue()))
            .andExpect(jsonPath("$.name").value(DEFAULT_NAME.toString()))
            .andExpect(jsonPath("$.description").value(DEFAULT_DESCRIPTION.toString()))
            .andExpect(jsonPath("$.schoolType").value(DEFAULT_SCHOOL_TYPE.toString()))
            .andExpect(jsonPath("$.category").value(DEFAULT_CATEGORY.toString()))
            .andExpect(jsonPath("$.singleUserMode").value(DEFAULT_SINGLE_USER_MODE.booleanValue()))
            .andExpect(jsonPath("$.spreadSheetId").value(DEFAULT_SPREAD_SHEET_ID.toString()))
            .andExpect(jsonPath("$.metadataContentType").value(DEFAULT_METADATA_CONTENT_TYPE))
            .andExpect(jsonPath("$.metadata").value(Base64Utils.encodeToString(DEFAULT_METADATA)));
    }

    @Test
    @Transactional
    public void getNonExistingMasterLab() throws Exception {
        // Get the masterLab
        restMasterLabMockMvc.perform(get("/api/master-labs/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateMasterLab() throws Exception {
        // Initialize the database
        masterLabRepository.saveAndFlush(masterLab);

        int databaseSizeBeforeUpdate = masterLabRepository.findAll().size();

        // Update the masterLab
        MasterLab updatedMasterLab = masterLabRepository.findById(masterLab.getId()).get();
        // Disconnect from session so that the updates on updatedMasterLab are not directly saved in db
        em.detach(updatedMasterLab);
        updatedMasterLab
            .name(UPDATED_NAME)
            .description(UPDATED_DESCRIPTION)
            .schoolType(UPDATED_SCHOOL_TYPE)
            .category(UPDATED_CATEGORY)
            .singleUserMode(UPDATED_SINGLE_USER_MODE)
            .spreadSheetId(UPDATED_SPREAD_SHEET_ID)
            .metadata(UPDATED_METADATA)
            .metadataContentType(UPDATED_METADATA_CONTENT_TYPE);

        restMasterLabMockMvc.perform(put("/api/master-labs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedMasterLab)))
            .andExpect(status().isOk());

        // Validate the MasterLab in the database
        List<MasterLab> masterLabList = masterLabRepository.findAll();
        assertThat(masterLabList).hasSize(databaseSizeBeforeUpdate);
        MasterLab testMasterLab = masterLabList.get(masterLabList.size() - 1);
        assertThat(testMasterLab.getName()).isEqualTo(UPDATED_NAME);
        assertThat(testMasterLab.getDescription()).isEqualTo(UPDATED_DESCRIPTION);
        assertThat(testMasterLab.getSchoolType()).isEqualTo(UPDATED_SCHOOL_TYPE);
        assertThat(testMasterLab.getCategory()).isEqualTo(UPDATED_CATEGORY);
        assertThat(testMasterLab.isSingleUserMode()).isEqualTo(UPDATED_SINGLE_USER_MODE);
        assertThat(testMasterLab.getSpreadSheetId()).isEqualTo(UPDATED_SPREAD_SHEET_ID);
        assertThat(testMasterLab.getMetadata()).isEqualTo(UPDATED_METADATA);
        assertThat(testMasterLab.getMetadataContentType()).isEqualTo(UPDATED_METADATA_CONTENT_TYPE);
    }

    @Test
    @Transactional
    public void updateNonExistingMasterLab() throws Exception {
        int databaseSizeBeforeUpdate = masterLabRepository.findAll().size();

        // Create the MasterLab

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restMasterLabMockMvc.perform(put("/api/master-labs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(masterLab)))
            .andExpect(status().isBadRequest());

        // Validate the MasterLab in the database
        List<MasterLab> masterLabList = masterLabRepository.findAll();
        assertThat(masterLabList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteMasterLab() throws Exception {
        // Initialize the database
        masterLabRepository.saveAndFlush(masterLab);

        int databaseSizeBeforeDelete = masterLabRepository.findAll().size();

        // Delete the masterLab
        restMasterLabMockMvc.perform(delete("/api/master-labs/{id}", masterLab.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<MasterLab> masterLabList = masterLabRepository.findAll();
        assertThat(masterLabList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(MasterLab.class);
        MasterLab masterLab1 = new MasterLab();
        masterLab1.setId(1L);
        MasterLab masterLab2 = new MasterLab();
        masterLab2.setId(masterLab1.getId());
        assertThat(masterLab1).isEqualTo(masterLab2);
        masterLab2.setId(2L);
        assertThat(masterLab1).isNotEqualTo(masterLab2);
        masterLab1.setId(null);
        assertThat(masterLab1).isNotEqualTo(masterLab2);
    }
}
