package com.activelearninglabs.web.rest;

import com.activelearninglabs.AllServerApp;
import com.activelearninglabs.domain.Audit;
import com.activelearninglabs.repository.AuditRepository;
import com.activelearninglabs.web.rest.errors.ExceptionTranslator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

import static com.activelearninglabs.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for the {@link AuditResource} REST controller.
 */
@SpringBootTest(classes = AllServerApp.class)
public class AuditResourceIT {

    private static final String DEFAULT_AUDIT_DATA = "AAAAAAAAAA";
    private static final String UPDATED_AUDIT_DATA = "BBBBBBBBBB";

    private static final LocalDate DEFAULT_AUDIT_DATE = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_AUDIT_DATE = LocalDate.now(ZoneId.systemDefault());
    private static final LocalDate SMALLER_AUDIT_DATE = LocalDate.ofEpochDay(-1L);

    private static final Long DEFAULT_LAB_ID = 1L;
    private static final Long UPDATED_LAB_ID = 2L;
    private static final Long SMALLER_LAB_ID = 1L - 1L;

    private static final Long DEFAULT_TEAM_ID = 1L;
    private static final Long UPDATED_TEAM_ID = 2L;
    private static final Long SMALLER_TEAM_ID = 1L - 1L;

    private static final Long DEFAULT_CLIENT_ID = 1L;
    private static final Long UPDATED_CLIENT_ID = 2L;
    private static final Long SMALLER_CLIENT_ID = 1L - 1L;

    private static final Long DEFAULT_CLASS_ROOM_ID = 1L;
    private static final Long UPDATED_CLASS_ROOM_ID = 2L;
    private static final Long SMALLER_CLASS_ROOM_ID = 1L - 1L;

    @Autowired
    private AuditRepository auditRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restAuditMockMvc;

    private Audit audit;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final AuditResource auditResource = new AuditResource(auditRepository);
        this.restAuditMockMvc = MockMvcBuilders.standaloneSetup(auditResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Audit createEntity(EntityManager em) {
        Audit audit = new Audit()
            .auditData(DEFAULT_AUDIT_DATA)
            .auditDate(DEFAULT_AUDIT_DATE)
            .labId(DEFAULT_LAB_ID)
            .teamId(DEFAULT_TEAM_ID)
            .clientId(DEFAULT_CLIENT_ID)
            .classRoomId(DEFAULT_CLASS_ROOM_ID);
        return audit;
    }
    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Audit createUpdatedEntity(EntityManager em) {
        Audit audit = new Audit()
            .auditData(UPDATED_AUDIT_DATA)
            .auditDate(UPDATED_AUDIT_DATE)
            .labId(UPDATED_LAB_ID)
            .teamId(UPDATED_TEAM_ID)
            .clientId(UPDATED_CLIENT_ID)
            .classRoomId(UPDATED_CLASS_ROOM_ID);
        return audit;
    }

    @BeforeEach
    public void initTest() {
        audit = createEntity(em);
    }

    @Test
    @Transactional
    public void createAudit() throws Exception {
        int databaseSizeBeforeCreate = auditRepository.findAll().size();

        // Create the Audit
        restAuditMockMvc.perform(post("/api/audits")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(audit)))
            .andExpect(status().isCreated());

        // Validate the Audit in the database
        List<Audit> auditList = auditRepository.findAll();
        assertThat(auditList).hasSize(databaseSizeBeforeCreate + 1);
        Audit testAudit = auditList.get(auditList.size() - 1);
        assertThat(testAudit.getAuditData()).isEqualTo(DEFAULT_AUDIT_DATA);
        assertThat(testAudit.getAuditDate()).isEqualTo(DEFAULT_AUDIT_DATE);
        assertThat(testAudit.getLabId()).isEqualTo(DEFAULT_LAB_ID);
        assertThat(testAudit.getTeamId()).isEqualTo(DEFAULT_TEAM_ID);
        assertThat(testAudit.getClientId()).isEqualTo(DEFAULT_CLIENT_ID);
        assertThat(testAudit.getClassRoomId()).isEqualTo(DEFAULT_CLASS_ROOM_ID);
    }

    @Test
    @Transactional
    public void createAuditWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = auditRepository.findAll().size();

        // Create the Audit with an existing ID
        audit.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restAuditMockMvc.perform(post("/api/audits")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(audit)))
            .andExpect(status().isBadRequest());

        // Validate the Audit in the database
        List<Audit> auditList = auditRepository.findAll();
        assertThat(auditList).hasSize(databaseSizeBeforeCreate);
    }


    @Test
    @Transactional
    public void getAllAudits() throws Exception {
        // Initialize the database
        auditRepository.saveAndFlush(audit);

        // Get all the auditList
        restAuditMockMvc.perform(get("/api/audits?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(audit.getId().intValue())))
            .andExpect(jsonPath("$.[*].auditData").value(hasItem(DEFAULT_AUDIT_DATA.toString())))
            .andExpect(jsonPath("$.[*].auditDate").value(hasItem(DEFAULT_AUDIT_DATE.toString())))
            .andExpect(jsonPath("$.[*].labId").value(hasItem(DEFAULT_LAB_ID.intValue())))
            .andExpect(jsonPath("$.[*].teamId").value(hasItem(DEFAULT_TEAM_ID.intValue())))
            .andExpect(jsonPath("$.[*].clientId").value(hasItem(DEFAULT_CLIENT_ID.intValue())))
            .andExpect(jsonPath("$.[*].classRoomId").value(hasItem(DEFAULT_CLASS_ROOM_ID.intValue())));
    }
    
    @Test
    @Transactional
    public void getAudit() throws Exception {
        // Initialize the database
        auditRepository.saveAndFlush(audit);

        // Get the audit
        restAuditMockMvc.perform(get("/api/audits/{id}", audit.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(audit.getId().intValue()))
            .andExpect(jsonPath("$.auditData").value(DEFAULT_AUDIT_DATA.toString()))
            .andExpect(jsonPath("$.auditDate").value(DEFAULT_AUDIT_DATE.toString()))
            .andExpect(jsonPath("$.labId").value(DEFAULT_LAB_ID.intValue()))
            .andExpect(jsonPath("$.teamId").value(DEFAULT_TEAM_ID.intValue()))
            .andExpect(jsonPath("$.clientId").value(DEFAULT_CLIENT_ID.intValue()))
            .andExpect(jsonPath("$.classRoomId").value(DEFAULT_CLASS_ROOM_ID.intValue()));
    }

    @Test
    @Transactional
    public void getNonExistingAudit() throws Exception {
        // Get the audit
        restAuditMockMvc.perform(get("/api/audits/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateAudit() throws Exception {
        // Initialize the database
        auditRepository.saveAndFlush(audit);

        int databaseSizeBeforeUpdate = auditRepository.findAll().size();

        // Update the audit
        Audit updatedAudit = auditRepository.findById(audit.getId()).get();
        // Disconnect from session so that the updates on updatedAudit are not directly saved in db
        em.detach(updatedAudit);
        updatedAudit
            .auditData(UPDATED_AUDIT_DATA)
            .auditDate(UPDATED_AUDIT_DATE)
            .labId(UPDATED_LAB_ID)
            .teamId(UPDATED_TEAM_ID)
            .clientId(UPDATED_CLIENT_ID)
            .classRoomId(UPDATED_CLASS_ROOM_ID);

        restAuditMockMvc.perform(put("/api/audits")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedAudit)))
            .andExpect(status().isOk());

        // Validate the Audit in the database
        List<Audit> auditList = auditRepository.findAll();
        assertThat(auditList).hasSize(databaseSizeBeforeUpdate);
        Audit testAudit = auditList.get(auditList.size() - 1);
        assertThat(testAudit.getAuditData()).isEqualTo(UPDATED_AUDIT_DATA);
        assertThat(testAudit.getAuditDate()).isEqualTo(UPDATED_AUDIT_DATE);
        assertThat(testAudit.getLabId()).isEqualTo(UPDATED_LAB_ID);
        assertThat(testAudit.getTeamId()).isEqualTo(UPDATED_TEAM_ID);
        assertThat(testAudit.getClientId()).isEqualTo(UPDATED_CLIENT_ID);
        assertThat(testAudit.getClassRoomId()).isEqualTo(UPDATED_CLASS_ROOM_ID);
    }

    @Test
    @Transactional
    public void updateNonExistingAudit() throws Exception {
        int databaseSizeBeforeUpdate = auditRepository.findAll().size();

        // Create the Audit

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restAuditMockMvc.perform(put("/api/audits")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(audit)))
            .andExpect(status().isBadRequest());

        // Validate the Audit in the database
        List<Audit> auditList = auditRepository.findAll();
        assertThat(auditList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    public void deleteAudit() throws Exception {
        // Initialize the database
        auditRepository.saveAndFlush(audit);

        int databaseSizeBeforeDelete = auditRepository.findAll().size();

        // Delete the audit
        restAuditMockMvc.perform(delete("/api/audits/{id}", audit.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<Audit> auditList = auditRepository.findAll();
        assertThat(auditList).hasSize(databaseSizeBeforeDelete - 1);
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Audit.class);
        Audit audit1 = new Audit();
        audit1.setId(1L);
        Audit audit2 = new Audit();
        audit2.setId(audit1.getId());
        assertThat(audit1).isEqualTo(audit2);
        audit2.setId(2L);
        assertThat(audit1).isNotEqualTo(audit2);
        audit1.setId(null);
        assertThat(audit1).isNotEqualTo(audit2);
    }
}
