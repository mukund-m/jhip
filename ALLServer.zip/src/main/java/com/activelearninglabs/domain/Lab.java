package com.activelearninglabs.domain;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

/**
 * A Lab.
 */
@Entity
@Table(name = "lab")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Lab implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "bought_on")
    private LocalDate boughtOn;

    @Column(name = "current_phase")
    private Integer currentPhase;

    @Column(name = "lab_endd_date")
    private LocalDate labEnddDate;

    @Column(name = "setup_complete")
    private Boolean setupComplete;

    @Column(name = "phase_running")
    private Boolean phaseRunning;

    @Column(name = "current_turn")
    private Integer currentTurn;

    @Column(name = "current_phase_category")
    private String currentPhaseCategory;

    @Column(name = "completion_complete")
    private Boolean completionComplete;

    @ManyToOne
    @JsonIgnoreProperties("labs")
    private MasterLab masterLab;

    @ManyToOne
    @JsonIgnoreProperties("labs")
    private ALLUser aLLUser;

    @ManyToOne
    @JsonIgnoreProperties("labs")
    private ClassRoom classRoom;

    @OneToMany(mappedBy = "lab")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Notification> notifications = new HashSet<>();

    @OneToMany(mappedBy = "lab")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<WorkerAssignment> workerAssignments = new HashSet<>();

    @OneToMany(mappedBy = "lab")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<StageSubmission> stageSubmissions = new HashSet<>();

    @OneToMany(mappedBy = "lab")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<TeacherAlert> teacherAlerts = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getBoughtOn() {
        return boughtOn;
    }

    public Lab boughtOn(LocalDate boughtOn) {
        this.boughtOn = boughtOn;
        return this;
    }

    public void setBoughtOn(LocalDate boughtOn) {
        this.boughtOn = boughtOn;
    }

    public Integer getCurrentPhase() {
        return currentPhase;
    }

    public Lab currentPhase(Integer currentPhase) {
        this.currentPhase = currentPhase;
        return this;
    }

    public void setCurrentPhase(Integer currentPhase) {
        this.currentPhase = currentPhase;
    }

    public LocalDate getLabEnddDate() {
        return labEnddDate;
    }

    public Lab labEnddDate(LocalDate labEnddDate) {
        this.labEnddDate = labEnddDate;
        return this;
    }

    public void setLabEnddDate(LocalDate labEnddDate) {
        this.labEnddDate = labEnddDate;
    }

    public Boolean isSetupComplete() {
        return setupComplete;
    }

    public Lab setupComplete(Boolean setupComplete) {
        this.setupComplete = setupComplete;
        return this;
    }

    public void setSetupComplete(Boolean setupComplete) {
        this.setupComplete = setupComplete;
    }

    public Boolean isPhaseRunning() {
        return phaseRunning;
    }

    public Lab phaseRunning(Boolean phaseRunning) {
        this.phaseRunning = phaseRunning;
        return this;
    }

    public void setPhaseRunning(Boolean phaseRunning) {
        this.phaseRunning = phaseRunning;
    }

    public Integer getCurrentTurn() {
        return currentTurn;
    }

    public Lab currentTurn(Integer currentTurn) {
        this.currentTurn = currentTurn;
        return this;
    }

    public void setCurrentTurn(Integer currentTurn) {
        this.currentTurn = currentTurn;
    }

    public String getCurrentPhaseCategory() {
        return currentPhaseCategory;
    }

    public Lab currentPhaseCategory(String currentPhaseCategory) {
        this.currentPhaseCategory = currentPhaseCategory;
        return this;
    }

    public void setCurrentPhaseCategory(String currentPhaseCategory) {
        this.currentPhaseCategory = currentPhaseCategory;
    }

    public Boolean isCompletionComplete() {
        return completionComplete;
    }

    public Lab completionComplete(Boolean completionComplete) {
        this.completionComplete = completionComplete;
        return this;
    }

    public void setCompletionComplete(Boolean completionComplete) {
        this.completionComplete = completionComplete;
    }

    public MasterLab getMasterLab() {
        return masterLab;
    }

    public Lab masterLab(MasterLab masterLab) {
        this.masterLab = masterLab;
        return this;
    }

    public void setMasterLab(MasterLab masterLab) {
        this.masterLab = masterLab;
    }

    public ALLUser getALLUser() {
        return aLLUser;
    }

    public Lab aLLUser(ALLUser aLLUser) {
        this.aLLUser = aLLUser;
        return this;
    }

    public void setALLUser(ALLUser aLLUser) {
        this.aLLUser = aLLUser;
    }

    public ClassRoom getClassRoom() {
        return classRoom;
    }

    public Lab classRoom(ClassRoom classRoom) {
        this.classRoom = classRoom;
        return this;
    }

    public void setClassRoom(ClassRoom classRoom) {
        this.classRoom = classRoom;
    }

    public Set<Notification> getNotifications() {
        return notifications;
    }

    public Lab notifications(Set<Notification> notifications) {
        this.notifications = notifications;
        return this;
    }

    public Lab addNotifications(Notification notification) {
        this.notifications.add(notification);
        notification.setLab(this);
        return this;
    }

    public Lab removeNotifications(Notification notification) {
        this.notifications.remove(notification);
        notification.setLab(null);
        return this;
    }

    public void setNotifications(Set<Notification> notifications) {
        this.notifications = notifications;
    }

    public Set<WorkerAssignment> getWorkerAssignments() {
        return workerAssignments;
    }

    public Lab workerAssignments(Set<WorkerAssignment> workerAssignments) {
        this.workerAssignments = workerAssignments;
        return this;
    }

    public Lab addWorkerAssignments(WorkerAssignment workerAssignment) {
        this.workerAssignments.add(workerAssignment);
        workerAssignment.setLab(this);
        return this;
    }

    public Lab removeWorkerAssignments(WorkerAssignment workerAssignment) {
        this.workerAssignments.remove(workerAssignment);
        workerAssignment.setLab(null);
        return this;
    }

    public void setWorkerAssignments(Set<WorkerAssignment> workerAssignments) {
        this.workerAssignments = workerAssignments;
    }

    public Set<StageSubmission> getStageSubmissions() {
        return stageSubmissions;
    }

    public Lab stageSubmissions(Set<StageSubmission> stageSubmissions) {
        this.stageSubmissions = stageSubmissions;
        return this;
    }

    public Lab addStageSubmissions(StageSubmission stageSubmission) {
        this.stageSubmissions.add(stageSubmission);
        stageSubmission.setLab(this);
        return this;
    }

    public Lab removeStageSubmissions(StageSubmission stageSubmission) {
        this.stageSubmissions.remove(stageSubmission);
        stageSubmission.setLab(null);
        return this;
    }

    public void setStageSubmissions(Set<StageSubmission> stageSubmissions) {
        this.stageSubmissions = stageSubmissions;
    }

    public Set<TeacherAlert> getTeacherAlerts() {
        return teacherAlerts;
    }

    public Lab teacherAlerts(Set<TeacherAlert> teacherAlerts) {
        this.teacherAlerts = teacherAlerts;
        return this;
    }

    public Lab addTeacherAlerts(TeacherAlert teacherAlert) {
        this.teacherAlerts.add(teacherAlert);
        teacherAlert.setLab(this);
        return this;
    }

    public Lab removeTeacherAlerts(TeacherAlert teacherAlert) {
        this.teacherAlerts.remove(teacherAlert);
        teacherAlert.setLab(null);
        return this;
    }

    public void setTeacherAlerts(Set<TeacherAlert> teacherAlerts) {
        this.teacherAlerts = teacherAlerts;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Lab)) {
            return false;
        }
        return id != null && id.equals(((Lab) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Lab{" +
            "id=" + getId() +
            ", boughtOn='" + getBoughtOn() + "'" +
            ", currentPhase=" + getCurrentPhase() +
            ", labEnddDate='" + getLabEnddDate() + "'" +
            ", setupComplete='" + isSetupComplete() + "'" +
            ", phaseRunning='" + isPhaseRunning() + "'" +
            ", currentTurn=" + getCurrentTurn() +
            ", currentPhaseCategory='" + getCurrentPhaseCategory() + "'" +
            ", completionComplete='" + isCompletionComplete() + "'" +
            "}";
    }
}
