package com.activelearninglabs.domain;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * A ClassRoom.
 */
@Entity
@Table(name = "class_room")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class ClassRoom implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "drive_folder_id")
    private String driveFolderId;

    @ManyToOne
    @JsonIgnoreProperties("classRooms")
    private Client client;

    @OneToMany(mappedBy = "classRoom")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Lab> labs = new HashSet<>();

    @OneToMany(mappedBy = "classRoom")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<ALLUser> users = new HashSet<>();

    @OneToMany(mappedBy = "classRoom")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Notification> notifications = new HashSet<>();

    @OneToMany(mappedBy = "classRoom")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Team> teams = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public ClassRoom name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDriveFolderId() {
        return driveFolderId;
    }

    public ClassRoom driveFolderId(String driveFolderId) {
        this.driveFolderId = driveFolderId;
        return this;
    }

    public void setDriveFolderId(String driveFolderId) {
        this.driveFolderId = driveFolderId;
    }

    public Client getClient() {
        return client;
    }

    public ClassRoom client(Client client) {
        this.client = client;
        return this;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Set<Lab> getLabs() {
        return labs;
    }

    public ClassRoom labs(Set<Lab> labs) {
        this.labs = labs;
        return this;
    }

    public ClassRoom addLabs(Lab lab) {
        this.labs.add(lab);
        lab.setClassRoom(this);
        return this;
    }

    public ClassRoom removeLabs(Lab lab) {
        this.labs.remove(lab);
        lab.setClassRoom(null);
        return this;
    }

    public void setLabs(Set<Lab> labs) {
        this.labs = labs;
    }

    public Set<ALLUser> getUsers() {
        return users;
    }

    public ClassRoom users(Set<ALLUser> aLLUsers) {
        this.users = aLLUsers;
        return this;
    }

    public ClassRoom addUsers(ALLUser aLLUser) {
        this.users.add(aLLUser);
        aLLUser.setClassRoom(this);
        return this;
    }

    public ClassRoom removeUsers(ALLUser aLLUser) {
        this.users.remove(aLLUser);
        aLLUser.setClassRoom(null);
        return this;
    }

    public void setUsers(Set<ALLUser> aLLUsers) {
        this.users = aLLUsers;
    }

    public Set<Notification> getNotifications() {
        return notifications;
    }

    public ClassRoom notifications(Set<Notification> notifications) {
        this.notifications = notifications;
        return this;
    }

    public ClassRoom addNotifications(Notification notification) {
        this.notifications.add(notification);
        notification.setClassRoom(this);
        return this;
    }

    public ClassRoom removeNotifications(Notification notification) {
        this.notifications.remove(notification);
        notification.setClassRoom(null);
        return this;
    }

    public void setNotifications(Set<Notification> notifications) {
        this.notifications = notifications;
    }

    public Set<Team> getTeams() {
        return teams;
    }

    public ClassRoom teams(Set<Team> teams) {
        this.teams = teams;
        return this;
    }

    public ClassRoom addTeams(Team team) {
        this.teams.add(team);
        team.setClassRoom(this);
        return this;
    }

    public ClassRoom removeTeams(Team team) {
        this.teams.remove(team);
        team.setClassRoom(null);
        return this;
    }

    public void setTeams(Set<Team> teams) {
        this.teams = teams;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ClassRoom)) {
            return false;
        }
        return id != null && id.equals(((ClassRoom) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "ClassRoom{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", driveFolderId='" + getDriveFolderId() + "'" +
            "}";
    }
}
