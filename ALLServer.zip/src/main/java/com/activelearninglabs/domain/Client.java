package com.activelearninglabs.domain;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * A Client.
 */
@Entity
@Table(name = "client")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Client implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "max_student_per_team")
    private Integer maxStudentPerTeam;

    @Column(name = "drive_folder_id")
    private String driveFolderId;

    @OneToMany(mappedBy = "client")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<ALLUser> users = new HashSet<>();

    @OneToMany(mappedBy = "client")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<ClassRoom> classRooms = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public Client name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMaxStudentPerTeam() {
        return maxStudentPerTeam;
    }

    public Client maxStudentPerTeam(Integer maxStudentPerTeam) {
        this.maxStudentPerTeam = maxStudentPerTeam;
        return this;
    }

    public void setMaxStudentPerTeam(Integer maxStudentPerTeam) {
        this.maxStudentPerTeam = maxStudentPerTeam;
    }

    public String getDriveFolderId() {
        return driveFolderId;
    }

    public Client driveFolderId(String driveFolderId) {
        this.driveFolderId = driveFolderId;
        return this;
    }

    public void setDriveFolderId(String driveFolderId) {
        this.driveFolderId = driveFolderId;
    }

    public Set<ALLUser> getUsers() {
        return users;
    }

    public Client users(Set<ALLUser> aLLUsers) {
        this.users = aLLUsers;
        return this;
    }

    public Client addUsers(ALLUser aLLUser) {
        this.users.add(aLLUser);
        aLLUser.setClient(this);
        return this;
    }

    public Client removeUsers(ALLUser aLLUser) {
        this.users.remove(aLLUser);
        aLLUser.setClient(null);
        return this;
    }

    public void setUsers(Set<ALLUser> aLLUsers) {
        this.users = aLLUsers;
    }

    public Set<ClassRoom> getClassRooms() {
        return classRooms;
    }

    public Client classRooms(Set<ClassRoom> classRooms) {
        this.classRooms = classRooms;
        return this;
    }

    public Client addClassRooms(ClassRoom classRoom) {
        this.classRooms.add(classRoom);
        classRoom.setClient(this);
        return this;
    }

    public Client removeClassRooms(ClassRoom classRoom) {
        this.classRooms.remove(classRoom);
        classRoom.setClient(null);
        return this;
    }

    public void setClassRooms(Set<ClassRoom> classRooms) {
        this.classRooms = classRooms;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Client)) {
            return false;
        }
        return id != null && id.equals(((Client) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Client{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", maxStudentPerTeam=" + getMaxStudentPerTeam() +
            ", driveFolderId='" + getDriveFolderId() + "'" +
            "}";
    }
}
