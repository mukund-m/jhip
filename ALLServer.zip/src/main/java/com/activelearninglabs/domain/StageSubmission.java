package com.activelearninglabs.domain;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * A StageSubmission.
 */
@Entity
@Table(name = "stage_submission")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class StageSubmission implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "submitted_date")
    private LocalDate submittedDate;

    @Column(name = "sheet_name")
    private String sheetName;

    @Column(name = "sheet_category")
    private String sheetCategory;

    @Column(name = "stage_num")
    private Integer stageNum;

    @Column(name = "turn_num")
    private Integer turnNum;

    @ManyToOne
    @JsonIgnoreProperties("stageSubmissions")
    private Lab lab;

    @OneToOne
    @JoinColumn(unique = true)
    private ALLUser user;

    @OneToOne
    @JoinColumn(unique = true)
    private Team team;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getSubmittedDate() {
        return submittedDate;
    }

    public StageSubmission submittedDate(LocalDate submittedDate) {
        this.submittedDate = submittedDate;
        return this;
    }

    public void setSubmittedDate(LocalDate submittedDate) {
        this.submittedDate = submittedDate;
    }

    public String getSheetName() {
        return sheetName;
    }

    public StageSubmission sheetName(String sheetName) {
        this.sheetName = sheetName;
        return this;
    }

    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }

    public String getSheetCategory() {
        return sheetCategory;
    }

    public StageSubmission sheetCategory(String sheetCategory) {
        this.sheetCategory = sheetCategory;
        return this;
    }

    public void setSheetCategory(String sheetCategory) {
        this.sheetCategory = sheetCategory;
    }

    public Integer getStageNum() {
        return stageNum;
    }

    public StageSubmission stageNum(Integer stageNum) {
        this.stageNum = stageNum;
        return this;
    }

    public void setStageNum(Integer stageNum) {
        this.stageNum = stageNum;
    }

    public Integer getTurnNum() {
        return turnNum;
    }

    public StageSubmission turnNum(Integer turnNum) {
        this.turnNum = turnNum;
        return this;
    }

    public void setTurnNum(Integer turnNum) {
        this.turnNum = turnNum;
    }

    public Lab getLab() {
        return lab;
    }

    public StageSubmission lab(Lab lab) {
        this.lab = lab;
        return this;
    }

    public void setLab(Lab lab) {
        this.lab = lab;
    }

    public ALLUser getUser() {
        return user;
    }

    public StageSubmission user(ALLUser aLLUser) {
        this.user = aLLUser;
        return this;
    }

    public void setUser(ALLUser aLLUser) {
        this.user = aLLUser;
    }

    public Team getTeam() {
        return team;
    }

    public StageSubmission team(Team team) {
        this.team = team;
        return this;
    }

    public void setTeam(Team team) {
        this.team = team;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof StageSubmission)) {
            return false;
        }
        return id != null && id.equals(((StageSubmission) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "StageSubmission{" +
            "id=" + getId() +
            ", submittedDate='" + getSubmittedDate() + "'" +
            ", sheetName='" + getSheetName() + "'" +
            ", sheetCategory='" + getSheetCategory() + "'" +
            ", stageNum=" + getStageNum() +
            ", turnNum=" + getTurnNum() +
            "}";
    }
}
