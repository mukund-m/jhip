package com.activelearninglabs.domain;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;

/**
 * A WorkerAssignment.
 */
@Entity
@Table(name = "worker_assignment")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class WorkerAssignment implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "stage")
    private String stage;

    @Column(name = "email_id")
    private String emailId;

    @ManyToOne
    @JsonIgnoreProperties("workerAssignments")
    private Lab lab;

    @OneToOne
    @JoinColumn(unique = true)
    private Team team;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStage() {
        return stage;
    }

    public WorkerAssignment stage(String stage) {
        this.stage = stage;
        return this;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getEmailId() {
        return emailId;
    }

    public WorkerAssignment emailId(String emailId) {
        this.emailId = emailId;
        return this;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public Lab getLab() {
        return lab;
    }

    public WorkerAssignment lab(Lab lab) {
        this.lab = lab;
        return this;
    }

    public void setLab(Lab lab) {
        this.lab = lab;
    }

    public Team getTeam() {
        return team;
    }

    public WorkerAssignment team(Team team) {
        this.team = team;
        return this;
    }

    public void setTeam(Team team) {
        this.team = team;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof WorkerAssignment)) {
            return false;
        }
        return id != null && id.equals(((WorkerAssignment) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "WorkerAssignment{" +
            "id=" + getId() +
            ", stage='" + getStage() + "'" +
            ", emailId='" + getEmailId() + "'" +
            "}";
    }
}
