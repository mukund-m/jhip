package com.activelearninglabs.domain;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * A Topic.
 */
@Entity
@Table(name = "topic")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Topic implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "name")
    private String name;

    @OneToMany(mappedBy = "topic")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<WorkbookUpload> workbookUploads = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public Topic name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<WorkbookUpload> getWorkbookUploads() {
        return workbookUploads;
    }

    public Topic workbookUploads(Set<WorkbookUpload> workbookUploads) {
        this.workbookUploads = workbookUploads;
        return this;
    }

    public Topic addWorkbookUploads(WorkbookUpload workbookUpload) {
        this.workbookUploads.add(workbookUpload);
        workbookUpload.setTopic(this);
        return this;
    }

    public Topic removeWorkbookUploads(WorkbookUpload workbookUpload) {
        this.workbookUploads.remove(workbookUpload);
        workbookUpload.setTopic(null);
        return this;
    }

    public void setWorkbookUploads(Set<WorkbookUpload> workbookUploads) {
        this.workbookUploads = workbookUploads;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Topic)) {
            return false;
        }
        return id != null && id.equals(((Topic) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Topic{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            "}";
    }
}
