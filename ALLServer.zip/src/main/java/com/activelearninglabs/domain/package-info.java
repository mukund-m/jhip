/**
 * JPA domain objects.
 */
package com.activelearninglabs.domain;
