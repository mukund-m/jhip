package com.activelearninglabs.domain;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * A MasterLab.
 */
@Entity
@Table(name = "master_lab")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class MasterLab implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "school_type")
    private String schoolType;

    @Column(name = "category")
    private String category;

    @Column(name = "single_user_mode")
    private Boolean singleUserMode;

    @Column(name = "spread_sheet_id")
    private String spreadSheetId;

    @Lob
    @Column(name = "metadata")
    private byte[] metadata;

    @Column(name = "metadata_content_type")
    private String metadataContentType;

    @OneToOne
    @JoinColumn(unique = true)
    private ActionTopicMapping actionTopicMappings;

    @OneToMany(mappedBy = "masterLab")
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Lab> labs = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public MasterLab name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public MasterLab description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSchoolType() {
        return schoolType;
    }

    public MasterLab schoolType(String schoolType) {
        this.schoolType = schoolType;
        return this;
    }

    public void setSchoolType(String schoolType) {
        this.schoolType = schoolType;
    }

    public String getCategory() {
        return category;
    }

    public MasterLab category(String category) {
        this.category = category;
        return this;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Boolean isSingleUserMode() {
        return singleUserMode;
    }

    public MasterLab singleUserMode(Boolean singleUserMode) {
        this.singleUserMode = singleUserMode;
        return this;
    }

    public void setSingleUserMode(Boolean singleUserMode) {
        this.singleUserMode = singleUserMode;
    }

    public String getSpreadSheetId() {
        return spreadSheetId;
    }

    public MasterLab spreadSheetId(String spreadSheetId) {
        this.spreadSheetId = spreadSheetId;
        return this;
    }

    public void setSpreadSheetId(String spreadSheetId) {
        this.spreadSheetId = spreadSheetId;
    }

    public byte[] getMetadata() {
        return metadata;
    }

    public MasterLab metadata(byte[] metadata) {
        this.metadata = metadata;
        return this;
    }

    public void setMetadata(byte[] metadata) {
        this.metadata = metadata;
    }

    public String getMetadataContentType() {
        return metadataContentType;
    }

    public MasterLab metadataContentType(String metadataContentType) {
        this.metadataContentType = metadataContentType;
        return this;
    }

    public void setMetadataContentType(String metadataContentType) {
        this.metadataContentType = metadataContentType;
    }

    public ActionTopicMapping getActionTopicMappings() {
        return actionTopicMappings;
    }

    public MasterLab actionTopicMappings(ActionTopicMapping actionTopicMapping) {
        this.actionTopicMappings = actionTopicMapping;
        return this;
    }

    public void setActionTopicMappings(ActionTopicMapping actionTopicMapping) {
        this.actionTopicMappings = actionTopicMapping;
    }

    public Set<Lab> getLabs() {
        return labs;
    }

    public MasterLab labs(Set<Lab> labs) {
        this.labs = labs;
        return this;
    }

    public MasterLab addLabs(Lab lab) {
        this.labs.add(lab);
        lab.setMasterLab(this);
        return this;
    }

    public MasterLab removeLabs(Lab lab) {
        this.labs.remove(lab);
        lab.setMasterLab(null);
        return this;
    }

    public void setLabs(Set<Lab> labs) {
        this.labs = labs;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MasterLab)) {
            return false;
        }
        return id != null && id.equals(((MasterLab) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "MasterLab{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", description='" + getDescription() + "'" +
            ", schoolType='" + getSchoolType() + "'" +
            ", category='" + getCategory() + "'" +
            ", singleUserMode='" + isSingleUserMode() + "'" +
            ", spreadSheetId='" + getSpreadSheetId() + "'" +
            ", metadata='" + getMetadata() + "'" +
            ", metadataContentType='" + getMetadataContentType() + "'" +
            "}";
    }
}
