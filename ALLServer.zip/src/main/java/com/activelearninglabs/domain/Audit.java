package com.activelearninglabs.domain;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * A Audit.
 */
@Entity
@Table(name = "audit")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Audit implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "audit_data")
    private String auditData;

    @Column(name = "audit_date")
    private LocalDate auditDate;

    @Column(name = "lab_id")
    private Long labId;

    @Column(name = "team_id")
    private Long teamId;

    @Column(name = "client_id")
    private Long clientId;

    @Column(name = "class_room_id")
    private Long classRoomId;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAuditData() {
        return auditData;
    }

    public Audit auditData(String auditData) {
        this.auditData = auditData;
        return this;
    }

    public void setAuditData(String auditData) {
        this.auditData = auditData;
    }

    public LocalDate getAuditDate() {
        return auditDate;
    }

    public Audit auditDate(LocalDate auditDate) {
        this.auditDate = auditDate;
        return this;
    }

    public void setAuditDate(LocalDate auditDate) {
        this.auditDate = auditDate;
    }

    public Long getLabId() {
        return labId;
    }

    public Audit labId(Long labId) {
        this.labId = labId;
        return this;
    }

    public void setLabId(Long labId) {
        this.labId = labId;
    }

    public Long getTeamId() {
        return teamId;
    }

    public Audit teamId(Long teamId) {
        this.teamId = teamId;
        return this;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }

    public Long getClientId() {
        return clientId;
    }

    public Audit clientId(Long clientId) {
        this.clientId = clientId;
        return this;
    }

    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }

    public Long getClassRoomId() {
        return classRoomId;
    }

    public Audit classRoomId(Long classRoomId) {
        this.classRoomId = classRoomId;
        return this;
    }

    public void setClassRoomId(Long classRoomId) {
        this.classRoomId = classRoomId;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Audit)) {
            return false;
        }
        return id != null && id.equals(((Audit) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Audit{" +
            "id=" + getId() +
            ", auditData='" + getAuditData() + "'" +
            ", auditDate='" + getAuditDate() + "'" +
            ", labId=" + getLabId() +
            ", teamId=" + getTeamId() +
            ", clientId=" + getClientId() +
            ", classRoomId=" + getClassRoomId() +
            "}";
    }
}
