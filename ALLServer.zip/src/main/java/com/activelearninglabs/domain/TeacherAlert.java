package com.activelearninglabs.domain;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;

/**
 * A TeacherAlert.
 */
@Entity
@Table(name = "teacher_alert")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class TeacherAlert implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "alert_to")
    private String alertTo;

    @Column(name = "message")
    private String message;

    @Column(name = "type")
    private String type;

    @Column(name = "alert_to_team_id")
    private Integer alertToTeamId;

    @Column(name = "alert_to_user_id")
    private Integer alertToUserId;

    @ManyToOne
    @JsonIgnoreProperties("teacherAlerts")
    private Lab lab;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAlertTo() {
        return alertTo;
    }

    public TeacherAlert alertTo(String alertTo) {
        this.alertTo = alertTo;
        return this;
    }

    public void setAlertTo(String alertTo) {
        this.alertTo = alertTo;
    }

    public String getMessage() {
        return message;
    }

    public TeacherAlert message(String message) {
        this.message = message;
        return this;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public TeacherAlert type(String type) {
        this.type = type;
        return this;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getAlertToTeamId() {
        return alertToTeamId;
    }

    public TeacherAlert alertToTeamId(Integer alertToTeamId) {
        this.alertToTeamId = alertToTeamId;
        return this;
    }

    public void setAlertToTeamId(Integer alertToTeamId) {
        this.alertToTeamId = alertToTeamId;
    }

    public Integer getAlertToUserId() {
        return alertToUserId;
    }

    public TeacherAlert alertToUserId(Integer alertToUserId) {
        this.alertToUserId = alertToUserId;
        return this;
    }

    public void setAlertToUserId(Integer alertToUserId) {
        this.alertToUserId = alertToUserId;
    }

    public Lab getLab() {
        return lab;
    }

    public TeacherAlert lab(Lab lab) {
        this.lab = lab;
        return this;
    }

    public void setLab(Lab lab) {
        this.lab = lab;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TeacherAlert)) {
            return false;
        }
        return id != null && id.equals(((TeacherAlert) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "TeacherAlert{" +
            "id=" + getId() +
            ", alertTo='" + getAlertTo() + "'" +
            ", message='" + getMessage() + "'" +
            ", type='" + getType() + "'" +
            ", alertToTeamId=" + getAlertToTeamId() +
            ", alertToUserId=" + getAlertToUserId() +
            "}";
    }
}
