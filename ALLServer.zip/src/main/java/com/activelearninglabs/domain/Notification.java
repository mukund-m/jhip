package com.activelearninglabs.domain;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;

import java.io.Serializable;

/**
 * A Notification.
 */
@Entity
@Table(name = "notification")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Notification implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    private Long id;

    @Column(name = "notification")
    private String notification;

    @Column(name = "type")
    private String type;

    @Column(name = "to_teacher")
    private Boolean toTeacher;

    @ManyToOne
    @JsonIgnoreProperties("notifications")
    private ClassRoom classRoom;

    @ManyToOne
    @JsonIgnoreProperties("notifications")
    private Lab lab;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNotification() {
        return notification;
    }

    public Notification notification(String notification) {
        this.notification = notification;
        return this;
    }

    public void setNotification(String notification) {
        this.notification = notification;
    }

    public String getType() {
        return type;
    }

    public Notification type(String type) {
        this.type = type;
        return this;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean isToTeacher() {
        return toTeacher;
    }

    public Notification toTeacher(Boolean toTeacher) {
        this.toTeacher = toTeacher;
        return this;
    }

    public void setToTeacher(Boolean toTeacher) {
        this.toTeacher = toTeacher;
    }

    public ClassRoom getClassRoom() {
        return classRoom;
    }

    public Notification classRoom(ClassRoom classRoom) {
        this.classRoom = classRoom;
        return this;
    }

    public void setClassRoom(ClassRoom classRoom) {
        this.classRoom = classRoom;
    }

    public Lab getLab() {
        return lab;
    }

    public Notification lab(Lab lab) {
        this.lab = lab;
        return this;
    }

    public void setLab(Lab lab) {
        this.lab = lab;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Notification)) {
            return false;
        }
        return id != null && id.equals(((Notification) o).id);
    }

    @Override
    public int hashCode() {
        return 31;
    }

    @Override
    public String toString() {
        return "Notification{" +
            "id=" + getId() +
            ", notification='" + getNotification() + "'" +
            ", type='" + getType() + "'" +
            ", toTeacher='" + isToTeacher() + "'" +
            "}";
    }
}
