package com.activelearninglabs.web.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.activelearninglabs.domain.ALLUser;
import com.activelearninglabs.service.StudentService;
import com.google.firebase.auth.FirebaseAuthException;

@RestController("/api")
public class StudentResource {

	@Autowired
	private StudentService studentService;
	
	@PostMapping("/createUser")
	public boolean createUser(ALLUser user) {
		/**
		 * 1. Create firebase user
		 * 2. Create User
		 * 3. Create ALL User
		 */
		try {
			this.studentService.createUser(user);
			return true;
		} catch (FirebaseAuthException e) {
			return false;
		}
		
	}
	
	
}
