package com.activelearninglabs.web.rest;

import com.activelearninglabs.domain.TeacherAlert;
import com.activelearninglabs.repository.TeacherAlertRepository;
import com.activelearninglabs.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.activelearninglabs.domain.TeacherAlert}.
 */
@RestController
@RequestMapping("/api")
public class TeacherAlertResource {

    private final Logger log = LoggerFactory.getLogger(TeacherAlertResource.class);

    private static final String ENTITY_NAME = "teacherAlert";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final TeacherAlertRepository teacherAlertRepository;

    public TeacherAlertResource(TeacherAlertRepository teacherAlertRepository) {
        this.teacherAlertRepository = teacherAlertRepository;
    }

    /**
     * {@code POST  /teacher-alerts} : Create a new teacherAlert.
     *
     * @param teacherAlert the teacherAlert to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new teacherAlert, or with status {@code 400 (Bad Request)} if the teacherAlert has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/teacher-alerts")
    public ResponseEntity<TeacherAlert> createTeacherAlert(@RequestBody TeacherAlert teacherAlert) throws URISyntaxException {
        log.debug("REST request to save TeacherAlert : {}", teacherAlert);
        if (teacherAlert.getId() != null) {
            throw new BadRequestAlertException("A new teacherAlert cannot already have an ID", ENTITY_NAME, "idexists");
        }
        TeacherAlert result = teacherAlertRepository.save(teacherAlert);
        return ResponseEntity.created(new URI("/api/teacher-alerts/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /teacher-alerts} : Updates an existing teacherAlert.
     *
     * @param teacherAlert the teacherAlert to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated teacherAlert,
     * or with status {@code 400 (Bad Request)} if the teacherAlert is not valid,
     * or with status {@code 500 (Internal Server Error)} if the teacherAlert couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/teacher-alerts")
    public ResponseEntity<TeacherAlert> updateTeacherAlert(@RequestBody TeacherAlert teacherAlert) throws URISyntaxException {
        log.debug("REST request to update TeacherAlert : {}", teacherAlert);
        if (teacherAlert.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        TeacherAlert result = teacherAlertRepository.save(teacherAlert);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, teacherAlert.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /teacher-alerts} : get all the teacherAlerts.
     *

     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of teacherAlerts in body.
     */
    @GetMapping("/teacher-alerts")
    public List<TeacherAlert> getAllTeacherAlerts() {
        log.debug("REST request to get all TeacherAlerts");
        return teacherAlertRepository.findAll();
    }

    /**
     * {@code GET  /teacher-alerts/:id} : get the "id" teacherAlert.
     *
     * @param id the id of the teacherAlert to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the teacherAlert, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/teacher-alerts/{id}")
    public ResponseEntity<TeacherAlert> getTeacherAlert(@PathVariable Long id) {
        log.debug("REST request to get TeacherAlert : {}", id);
        Optional<TeacherAlert> teacherAlert = teacherAlertRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(teacherAlert);
    }

    /**
     * {@code DELETE  /teacher-alerts/:id} : delete the "id" teacherAlert.
     *
     * @param id the id of the teacherAlert to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/teacher-alerts/{id}")
    public ResponseEntity<Void> deleteTeacherAlert(@PathVariable Long id) {
        log.debug("REST request to delete TeacherAlert : {}", id);
        teacherAlertRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }
}
