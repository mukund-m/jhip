package com.activelearninglabs.web.rest;

import com.activelearninglabs.domain.MasterLab;
import com.activelearninglabs.repository.MasterLabRepository;
import com.activelearninglabs.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.activelearninglabs.domain.MasterLab}.
 */
@RestController
@RequestMapping("/api")
public class MasterLabResource {

    private final Logger log = LoggerFactory.getLogger(MasterLabResource.class);

    private static final String ENTITY_NAME = "masterLab";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final MasterLabRepository masterLabRepository;

    public MasterLabResource(MasterLabRepository masterLabRepository) {
        this.masterLabRepository = masterLabRepository;
    }

    /**
     * {@code POST  /master-labs} : Create a new masterLab.
     *
     * @param masterLab the masterLab to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new masterLab, or with status {@code 400 (Bad Request)} if the masterLab has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/master-labs")
    public ResponseEntity<MasterLab> createMasterLab(@RequestBody MasterLab masterLab) throws URISyntaxException {
        log.debug("REST request to save MasterLab : {}", masterLab);
        if (masterLab.getId() != null) {
            throw new BadRequestAlertException("A new masterLab cannot already have an ID", ENTITY_NAME, "idexists");
        }
        MasterLab result = masterLabRepository.save(masterLab);
        return ResponseEntity.created(new URI("/api/master-labs/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /master-labs} : Updates an existing masterLab.
     *
     * @param masterLab the masterLab to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated masterLab,
     * or with status {@code 400 (Bad Request)} if the masterLab is not valid,
     * or with status {@code 500 (Internal Server Error)} if the masterLab couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/master-labs")
    public ResponseEntity<MasterLab> updateMasterLab(@RequestBody MasterLab masterLab) throws URISyntaxException {
        log.debug("REST request to update MasterLab : {}", masterLab);
        if (masterLab.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        MasterLab result = masterLabRepository.save(masterLab);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, masterLab.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /master-labs} : get all the masterLabs.
     *

     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of masterLabs in body.
     */
    @GetMapping("/master-labs")
    public List<MasterLab> getAllMasterLabs() {
        log.debug("REST request to get all MasterLabs");
        return masterLabRepository.findAll();
    }

    /**
     * {@code GET  /master-labs/:id} : get the "id" masterLab.
     *
     * @param id the id of the masterLab to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the masterLab, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/master-labs/{id}")
    public ResponseEntity<MasterLab> getMasterLab(@PathVariable Long id) {
        log.debug("REST request to get MasterLab : {}", id);
        Optional<MasterLab> masterLab = masterLabRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(masterLab);
    }

    /**
     * {@code DELETE  /master-labs/:id} : delete the "id" masterLab.
     *
     * @param id the id of the masterLab to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/master-labs/{id}")
    public ResponseEntity<Void> deleteMasterLab(@PathVariable Long id) {
        log.debug("REST request to delete MasterLab : {}", id);
        masterLabRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }
}
