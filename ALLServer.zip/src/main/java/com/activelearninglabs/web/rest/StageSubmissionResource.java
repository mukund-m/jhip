package com.activelearninglabs.web.rest;

import com.activelearninglabs.domain.StageSubmission;
import com.activelearninglabs.repository.StageSubmissionRepository;
import com.activelearninglabs.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.activelearninglabs.domain.StageSubmission}.
 */
@RestController
@RequestMapping("/api")
public class StageSubmissionResource {

    private final Logger log = LoggerFactory.getLogger(StageSubmissionResource.class);

    private static final String ENTITY_NAME = "stageSubmission";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final StageSubmissionRepository stageSubmissionRepository;

    public StageSubmissionResource(StageSubmissionRepository stageSubmissionRepository) {
        this.stageSubmissionRepository = stageSubmissionRepository;
    }

    /**
     * {@code POST  /stage-submissions} : Create a new stageSubmission.
     *
     * @param stageSubmission the stageSubmission to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new stageSubmission, or with status {@code 400 (Bad Request)} if the stageSubmission has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/stage-submissions")
    public ResponseEntity<StageSubmission> createStageSubmission(@RequestBody StageSubmission stageSubmission) throws URISyntaxException {
        log.debug("REST request to save StageSubmission : {}", stageSubmission);
        if (stageSubmission.getId() != null) {
            throw new BadRequestAlertException("A new stageSubmission cannot already have an ID", ENTITY_NAME, "idexists");
        }
        StageSubmission result = stageSubmissionRepository.save(stageSubmission);
        return ResponseEntity.created(new URI("/api/stage-submissions/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /stage-submissions} : Updates an existing stageSubmission.
     *
     * @param stageSubmission the stageSubmission to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated stageSubmission,
     * or with status {@code 400 (Bad Request)} if the stageSubmission is not valid,
     * or with status {@code 500 (Internal Server Error)} if the stageSubmission couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/stage-submissions")
    public ResponseEntity<StageSubmission> updateStageSubmission(@RequestBody StageSubmission stageSubmission) throws URISyntaxException {
        log.debug("REST request to update StageSubmission : {}", stageSubmission);
        if (stageSubmission.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        StageSubmission result = stageSubmissionRepository.save(stageSubmission);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, stageSubmission.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /stage-submissions} : get all the stageSubmissions.
     *

     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of stageSubmissions in body.
     */
    @GetMapping("/stage-submissions")
    public List<StageSubmission> getAllStageSubmissions() {
        log.debug("REST request to get all StageSubmissions");
        return stageSubmissionRepository.findAll();
    }

    /**
     * {@code GET  /stage-submissions/:id} : get the "id" stageSubmission.
     *
     * @param id the id of the stageSubmission to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the stageSubmission, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/stage-submissions/{id}")
    public ResponseEntity<StageSubmission> getStageSubmission(@PathVariable Long id) {
        log.debug("REST request to get StageSubmission : {}", id);
        Optional<StageSubmission> stageSubmission = stageSubmissionRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(stageSubmission);
    }

    /**
     * {@code DELETE  /stage-submissions/:id} : delete the "id" stageSubmission.
     *
     * @param id the id of the stageSubmission to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/stage-submissions/{id}")
    public ResponseEntity<Void> deleteStageSubmission(@PathVariable Long id) {
        log.debug("REST request to delete StageSubmission : {}", id);
        stageSubmissionRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }
}
