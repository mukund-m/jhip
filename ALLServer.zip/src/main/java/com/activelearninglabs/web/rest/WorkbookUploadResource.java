package com.activelearninglabs.web.rest;

import com.activelearninglabs.domain.WorkbookUpload;
import com.activelearninglabs.repository.WorkbookUploadRepository;
import com.activelearninglabs.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.activelearninglabs.domain.WorkbookUpload}.
 */
@RestController
@RequestMapping("/api")
public class WorkbookUploadResource {

    private final Logger log = LoggerFactory.getLogger(WorkbookUploadResource.class);

    private static final String ENTITY_NAME = "workbookUpload";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final WorkbookUploadRepository workbookUploadRepository;

    public WorkbookUploadResource(WorkbookUploadRepository workbookUploadRepository) {
        this.workbookUploadRepository = workbookUploadRepository;
    }

    /**
     * {@code POST  /workbook-uploads} : Create a new workbookUpload.
     *
     * @param workbookUpload the workbookUpload to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new workbookUpload, or with status {@code 400 (Bad Request)} if the workbookUpload has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/workbook-uploads")
    public ResponseEntity<WorkbookUpload> createWorkbookUpload(@RequestBody WorkbookUpload workbookUpload) throws URISyntaxException {
        log.debug("REST request to save WorkbookUpload : {}", workbookUpload);
        if (workbookUpload.getId() != null) {
            throw new BadRequestAlertException("A new workbookUpload cannot already have an ID", ENTITY_NAME, "idexists");
        }
        WorkbookUpload result = workbookUploadRepository.save(workbookUpload);
        return ResponseEntity.created(new URI("/api/workbook-uploads/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /workbook-uploads} : Updates an existing workbookUpload.
     *
     * @param workbookUpload the workbookUpload to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated workbookUpload,
     * or with status {@code 400 (Bad Request)} if the workbookUpload is not valid,
     * or with status {@code 500 (Internal Server Error)} if the workbookUpload couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/workbook-uploads")
    public ResponseEntity<WorkbookUpload> updateWorkbookUpload(@RequestBody WorkbookUpload workbookUpload) throws URISyntaxException {
        log.debug("REST request to update WorkbookUpload : {}", workbookUpload);
        if (workbookUpload.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        WorkbookUpload result = workbookUploadRepository.save(workbookUpload);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, workbookUpload.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /workbook-uploads} : get all the workbookUploads.
     *

     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of workbookUploads in body.
     */
    @GetMapping("/workbook-uploads")
    public List<WorkbookUpload> getAllWorkbookUploads() {
        log.debug("REST request to get all WorkbookUploads");
        return workbookUploadRepository.findAll();
    }

    /**
     * {@code GET  /workbook-uploads/:id} : get the "id" workbookUpload.
     *
     * @param id the id of the workbookUpload to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the workbookUpload, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/workbook-uploads/{id}")
    public ResponseEntity<WorkbookUpload> getWorkbookUpload(@PathVariable Long id) {
        log.debug("REST request to get WorkbookUpload : {}", id);
        Optional<WorkbookUpload> workbookUpload = workbookUploadRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(workbookUpload);
    }

    /**
     * {@code DELETE  /workbook-uploads/:id} : delete the "id" workbookUpload.
     *
     * @param id the id of the workbookUpload to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/workbook-uploads/{id}")
    public ResponseEntity<Void> deleteWorkbookUpload(@PathVariable Long id) {
        log.debug("REST request to delete WorkbookUpload : {}", id);
        workbookUploadRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }
}
