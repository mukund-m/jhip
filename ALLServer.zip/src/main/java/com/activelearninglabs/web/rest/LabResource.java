package com.activelearninglabs.web.rest;

import com.activelearninglabs.domain.Lab;
import com.activelearninglabs.repository.LabRepository;
import com.activelearninglabs.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.activelearninglabs.domain.Lab}.
 */
@RestController
@RequestMapping("/api")
public class LabResource {

    private final Logger log = LoggerFactory.getLogger(LabResource.class);

    private static final String ENTITY_NAME = "lab";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final LabRepository labRepository;

    public LabResource(LabRepository labRepository) {
        this.labRepository = labRepository;
    }

    /**
     * {@code POST  /labs} : Create a new lab.
     *
     * @param lab the lab to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new lab, or with status {@code 400 (Bad Request)} if the lab has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/labs")
    public ResponseEntity<Lab> createLab(@RequestBody Lab lab) throws URISyntaxException {
        log.debug("REST request to save Lab : {}", lab);
        if (lab.getId() != null) {
            throw new BadRequestAlertException("A new lab cannot already have an ID", ENTITY_NAME, "idexists");
        }
        Lab result = labRepository.save(lab);
        return ResponseEntity.created(new URI("/api/labs/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /labs} : Updates an existing lab.
     *
     * @param lab the lab to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated lab,
     * or with status {@code 400 (Bad Request)} if the lab is not valid,
     * or with status {@code 500 (Internal Server Error)} if the lab couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/labs")
    public ResponseEntity<Lab> updateLab(@RequestBody Lab lab) throws URISyntaxException {
        log.debug("REST request to update Lab : {}", lab);
        if (lab.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        Lab result = labRepository.save(lab);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, lab.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /labs} : get all the labs.
     *

     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of labs in body.
     */
    @GetMapping("/labs")
    public List<Lab> getAllLabs() {
        log.debug("REST request to get all Labs");
        return labRepository.findAll();
    }

    /**
     * {@code GET  /labs/:id} : get the "id" lab.
     *
     * @param id the id of the lab to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the lab, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/labs/{id}")
    public ResponseEntity<Lab> getLab(@PathVariable Long id) {
        log.debug("REST request to get Lab : {}", id);
        Optional<Lab> lab = labRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(lab);
    }

    /**
     * {@code DELETE  /labs/:id} : delete the "id" lab.
     *
     * @param id the id of the lab to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/labs/{id}")
    public ResponseEntity<Void> deleteLab(@PathVariable Long id) {
        log.debug("REST request to delete Lab : {}", id);
        labRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }
}
