package com.activelearninglabs.web.rest;

import com.activelearninglabs.domain.WorkerAssignment;
import com.activelearninglabs.repository.WorkerAssignmentRepository;
import com.activelearninglabs.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.activelearninglabs.domain.WorkerAssignment}.
 */
@RestController
@RequestMapping("/api")
public class WorkerAssignmentResource {

    private final Logger log = LoggerFactory.getLogger(WorkerAssignmentResource.class);

    private static final String ENTITY_NAME = "workerAssignment";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final WorkerAssignmentRepository workerAssignmentRepository;

    public WorkerAssignmentResource(WorkerAssignmentRepository workerAssignmentRepository) {
        this.workerAssignmentRepository = workerAssignmentRepository;
    }

    /**
     * {@code POST  /worker-assignments} : Create a new workerAssignment.
     *
     * @param workerAssignment the workerAssignment to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new workerAssignment, or with status {@code 400 (Bad Request)} if the workerAssignment has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/worker-assignments")
    public ResponseEntity<WorkerAssignment> createWorkerAssignment(@RequestBody WorkerAssignment workerAssignment) throws URISyntaxException {
        log.debug("REST request to save WorkerAssignment : {}", workerAssignment);
        if (workerAssignment.getId() != null) {
            throw new BadRequestAlertException("A new workerAssignment cannot already have an ID", ENTITY_NAME, "idexists");
        }
        WorkerAssignment result = workerAssignmentRepository.save(workerAssignment);
        return ResponseEntity.created(new URI("/api/worker-assignments/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /worker-assignments} : Updates an existing workerAssignment.
     *
     * @param workerAssignment the workerAssignment to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated workerAssignment,
     * or with status {@code 400 (Bad Request)} if the workerAssignment is not valid,
     * or with status {@code 500 (Internal Server Error)} if the workerAssignment couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/worker-assignments")
    public ResponseEntity<WorkerAssignment> updateWorkerAssignment(@RequestBody WorkerAssignment workerAssignment) throws URISyntaxException {
        log.debug("REST request to update WorkerAssignment : {}", workerAssignment);
        if (workerAssignment.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        WorkerAssignment result = workerAssignmentRepository.save(workerAssignment);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, workerAssignment.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /worker-assignments} : get all the workerAssignments.
     *

     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of workerAssignments in body.
     */
    @GetMapping("/worker-assignments")
    public List<WorkerAssignment> getAllWorkerAssignments() {
        log.debug("REST request to get all WorkerAssignments");
        return workerAssignmentRepository.findAll();
    }

    /**
     * {@code GET  /worker-assignments/:id} : get the "id" workerAssignment.
     *
     * @param id the id of the workerAssignment to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the workerAssignment, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/worker-assignments/{id}")
    public ResponseEntity<WorkerAssignment> getWorkerAssignment(@PathVariable Long id) {
        log.debug("REST request to get WorkerAssignment : {}", id);
        Optional<WorkerAssignment> workerAssignment = workerAssignmentRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(workerAssignment);
    }

    /**
     * {@code DELETE  /worker-assignments/:id} : delete the "id" workerAssignment.
     *
     * @param id the id of the workerAssignment to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/worker-assignments/{id}")
    public ResponseEntity<Void> deleteWorkerAssignment(@PathVariable Long id) {
        log.debug("REST request to delete WorkerAssignment : {}", id);
        workerAssignmentRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }
}
