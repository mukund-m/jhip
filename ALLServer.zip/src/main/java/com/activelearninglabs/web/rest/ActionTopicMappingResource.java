package com.activelearninglabs.web.rest;

import com.activelearninglabs.domain.ActionTopicMapping;
import com.activelearninglabs.repository.ActionTopicMappingRepository;
import com.activelearninglabs.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.activelearninglabs.domain.ActionTopicMapping}.
 */
@RestController
@RequestMapping("/api")
public class ActionTopicMappingResource {

    private final Logger log = LoggerFactory.getLogger(ActionTopicMappingResource.class);

    private static final String ENTITY_NAME = "actionTopicMapping";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ActionTopicMappingRepository actionTopicMappingRepository;

    public ActionTopicMappingResource(ActionTopicMappingRepository actionTopicMappingRepository) {
        this.actionTopicMappingRepository = actionTopicMappingRepository;
    }

    /**
     * {@code POST  /action-topic-mappings} : Create a new actionTopicMapping.
     *
     * @param actionTopicMapping the actionTopicMapping to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new actionTopicMapping, or with status {@code 400 (Bad Request)} if the actionTopicMapping has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/action-topic-mappings")
    public ResponseEntity<ActionTopicMapping> createActionTopicMapping(@RequestBody ActionTopicMapping actionTopicMapping) throws URISyntaxException {
        log.debug("REST request to save ActionTopicMapping : {}", actionTopicMapping);
        if (actionTopicMapping.getId() != null) {
            throw new BadRequestAlertException("A new actionTopicMapping cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ActionTopicMapping result = actionTopicMappingRepository.save(actionTopicMapping);
        return ResponseEntity.created(new URI("/api/action-topic-mappings/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /action-topic-mappings} : Updates an existing actionTopicMapping.
     *
     * @param actionTopicMapping the actionTopicMapping to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated actionTopicMapping,
     * or with status {@code 400 (Bad Request)} if the actionTopicMapping is not valid,
     * or with status {@code 500 (Internal Server Error)} if the actionTopicMapping couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/action-topic-mappings")
    public ResponseEntity<ActionTopicMapping> updateActionTopicMapping(@RequestBody ActionTopicMapping actionTopicMapping) throws URISyntaxException {
        log.debug("REST request to update ActionTopicMapping : {}", actionTopicMapping);
        if (actionTopicMapping.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        ActionTopicMapping result = actionTopicMappingRepository.save(actionTopicMapping);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, actionTopicMapping.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /action-topic-mappings} : get all the actionTopicMappings.
     *

     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of actionTopicMappings in body.
     */
    @GetMapping("/action-topic-mappings")
    public List<ActionTopicMapping> getAllActionTopicMappings() {
        log.debug("REST request to get all ActionTopicMappings");
        return actionTopicMappingRepository.findAll();
    }

    /**
     * {@code GET  /action-topic-mappings/:id} : get the "id" actionTopicMapping.
     *
     * @param id the id of the actionTopicMapping to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the actionTopicMapping, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/action-topic-mappings/{id}")
    public ResponseEntity<ActionTopicMapping> getActionTopicMapping(@PathVariable Long id) {
        log.debug("REST request to get ActionTopicMapping : {}", id);
        Optional<ActionTopicMapping> actionTopicMapping = actionTopicMappingRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(actionTopicMapping);
    }

    /**
     * {@code DELETE  /action-topic-mappings/:id} : delete the "id" actionTopicMapping.
     *
     * @param id the id of the actionTopicMapping to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/action-topic-mappings/{id}")
    public ResponseEntity<Void> deleteActionTopicMapping(@PathVariable Long id) {
        log.debug("REST request to delete ActionTopicMapping : {}", id);
        actionTopicMappingRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }
}
