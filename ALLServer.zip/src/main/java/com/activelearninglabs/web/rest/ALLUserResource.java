package com.activelearninglabs.web.rest;

import com.activelearninglabs.domain.ALLUser;
import com.activelearninglabs.repository.ALLUserRepository;
import com.activelearninglabs.web.rest.errors.BadRequestAlertException;

import io.github.jhipster.web.util.HeaderUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing {@link com.activelearninglabs.domain.ALLUser}.
 */
@RestController
@RequestMapping("/api")
public class ALLUserResource {

    private final Logger log = LoggerFactory.getLogger(ALLUserResource.class);

    private static final String ENTITY_NAME = "aLLUser";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final ALLUserRepository aLLUserRepository;

    public ALLUserResource(ALLUserRepository aLLUserRepository) {
        this.aLLUserRepository = aLLUserRepository;
    }

    /**
     * {@code POST  /all-users} : Create a new aLLUser.
     *
     * @param aLLUser the aLLUser to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new aLLUser, or with status {@code 400 (Bad Request)} if the aLLUser has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("/all-users")
    public ResponseEntity<ALLUser> createALLUser(@RequestBody ALLUser aLLUser) throws URISyntaxException {
        log.debug("REST request to save ALLUser : {}", aLLUser);
        if (aLLUser.getId() != null) {
            throw new BadRequestAlertException("A new aLLUser cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ALLUser result = aLLUserRepository.save(aLLUser);
        return ResponseEntity.created(new URI("/api/all-users/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /all-users} : Updates an existing aLLUser.
     *
     * @param aLLUser the aLLUser to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated aLLUser,
     * or with status {@code 400 (Bad Request)} if the aLLUser is not valid,
     * or with status {@code 500 (Internal Server Error)} if the aLLUser couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/all-users")
    public ResponseEntity<ALLUser> updateALLUser(@RequestBody ALLUser aLLUser) throws URISyntaxException {
        log.debug("REST request to update ALLUser : {}", aLLUser);
        if (aLLUser.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        ALLUser result = aLLUserRepository.save(aLLUser);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, aLLUser.getId().toString()))
            .body(result);
    }

    /**
     * {@code GET  /all-users} : get all the aLLUsers.
     *

     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of aLLUsers in body.
     */
    @GetMapping("/all-users")
    public List<ALLUser> getAllALLUsers() {
        log.debug("REST request to get all ALLUsers");
        return aLLUserRepository.findAll();
    }

    /**
     * {@code GET  /all-users/:id} : get the "id" aLLUser.
     *
     * @param id the id of the aLLUser to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the aLLUser, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/all-users/{id}")
    public ResponseEntity<ALLUser> getALLUser(@PathVariable Long id) {
        log.debug("REST request to get ALLUser : {}", id);
        Optional<ALLUser> aLLUser = aLLUserRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(aLLUser);
    }

    /**
     * {@code DELETE  /all-users/:id} : delete the "id" aLLUser.
     *
     * @param id the id of the aLLUser to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/all-users/{id}")
    public ResponseEntity<Void> deleteALLUser(@PathVariable Long id) {
        log.debug("REST request to delete ALLUser : {}", id);
        aLLUserRepository.deleteById(id);
        return ResponseEntity.noContent().headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString())).build();
    }
}
