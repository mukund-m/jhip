package com.activelearninglabs.firebase;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;
import com.google.firebase.internal.FirebaseService;

import io.netty.util.internal.StringUtil;
@Component
public class FirebaseFilter extends OncePerRequestFilter {

	private static String HEADER_NAME = "X-Authorization-Firebase";


	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String xAuth = request.getHeader(HEADER_NAME);
		if (xAuth.isEmpty()) {
			filterChain.doFilter(request, response);
			return;
		} else {
			try {
				FirebaseTokenHolder holder = this.parseToken(xAuth);

				String userName = holder.getUid();

				Authentication auth = new FirebaseAuthenticationToken(userName, holder);
				SecurityContextHolder.getContext().setAuthentication(auth);

				filterChain.doFilter(request, response);
			} catch (Exception e) {
				throw new SecurityException(e);
			}
		}
	}
	
	public FirebaseTokenHolder parseToken(String idToken) {
		if (idToken.trim().isEmpty()) {
			throw new IllegalArgumentException("FirebaseTokenBlank");
		}
		try {
			FirebaseToken decodedToken = FirebaseAuth.getInstance(FirebaseConfig.getInstance().getApp())
					.verifyIdToken(idToken);
			String uuid = decodedToken.getUid();
			return new FirebaseTokenHolder(decodedToken);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}
}