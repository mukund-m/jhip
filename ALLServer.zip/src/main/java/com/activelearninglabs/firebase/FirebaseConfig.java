package com.activelearninglabs.firebase;

import java.io.FileInputStream;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.FirestoreOptions;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;

public class FirebaseConfig {

	private static FirebaseConfig firebaseConfig = null;
	private Firestore firestore = null;
	private FirebaseApp app = null;
	private FirebaseAuth auth = null;
	private Logger logger = LoggerFactory.getLogger(FirebaseConfig.class);

	private FirebaseConfig() {

	}

	public static FirebaseConfig getInstance() {

		if (firebaseConfig == null) {
			firebaseConfig = new FirebaseConfig();
			firebaseConfig.initialize();

		}
		return firebaseConfig;
	}

	private void initialize() {
		try {

			GoogleCredentials credentials = GoogleCredentials.fromStream(new FileInputStream(
					"D:\\tasks\\codementor\\ActiveLearningLabServer\\LabServer\\LabServer\\src\\main\\resources\\activelearning-56fc3-firebase-adminsdk-or0uo-805bffe060.json"));
			FirebaseOptions firebaseOptions = new FirebaseOptions.Builder().setCredentials(credentials)
					.setDatabaseUrl("https://activelearning-56fc3.firebaseio.com").build();
			if(FirebaseApp.getApps().size() == 0) {
				app = FirebaseApp.initializeApp(firebaseOptions);
			} else {
				app = FirebaseApp.getApps().get(0);
			}
			firestore = FirestoreOptions.newBuilder().setCredentials(credentials).build().getService();
			auth = FirebaseAuth.getInstance(app);
			logger.debug("Initialized firebase app");
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public Firestore getFirestore() {
		return firestore;
	}

	public void setFirestore(Firestore firestore) {
		this.firestore = firestore;
	}

	public FirebaseApp getApp() {
		return app;
	}
	
	public FirebaseAuth getAuth() {
		return auth;
	}

	public void setApp(FirebaseApp app) {
		this.app = app;
	}

}
