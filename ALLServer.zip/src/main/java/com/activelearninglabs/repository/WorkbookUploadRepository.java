package com.activelearninglabs.repository;
import com.activelearninglabs.domain.WorkbookUpload;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the WorkbookUpload entity.
 */
@SuppressWarnings("unused")
@Repository
public interface WorkbookUploadRepository extends JpaRepository<WorkbookUpload, Long> {

}
