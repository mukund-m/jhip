package com.activelearninglabs.repository;
import com.activelearninglabs.domain.MasterLab;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the MasterLab entity.
 */
@SuppressWarnings("unused")
@Repository
public interface MasterLabRepository extends JpaRepository<MasterLab, Long> {

}
