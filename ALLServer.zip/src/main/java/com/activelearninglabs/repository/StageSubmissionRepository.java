package com.activelearninglabs.repository;
import com.activelearninglabs.domain.StageSubmission;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the StageSubmission entity.
 */
@SuppressWarnings("unused")
@Repository
public interface StageSubmissionRepository extends JpaRepository<StageSubmission, Long> {

}
