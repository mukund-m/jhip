/**
 * Spring Data JPA repositories.
 */
package com.activelearninglabs.repository;
