package com.activelearninglabs.repository;
import com.activelearninglabs.domain.WorkerAssignment;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the WorkerAssignment entity.
 */
@SuppressWarnings("unused")
@Repository
public interface WorkerAssignmentRepository extends JpaRepository<WorkerAssignment, Long> {

}
