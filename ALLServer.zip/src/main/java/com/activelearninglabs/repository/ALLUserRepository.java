package com.activelearninglabs.repository;
import com.activelearninglabs.domain.ALLUser;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the ALLUser entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ALLUserRepository extends JpaRepository<ALLUser, Long> {

	public ALLUser findByUid(String uid);
}
