package com.activelearninglabs.repository;
import com.activelearninglabs.domain.TeacherAlert;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the TeacherAlert entity.
 */
@SuppressWarnings("unused")
@Repository
public interface TeacherAlertRepository extends JpaRepository<TeacherAlert, Long> {

}
