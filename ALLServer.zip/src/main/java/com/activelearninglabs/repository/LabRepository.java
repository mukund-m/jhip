package com.activelearninglabs.repository;
import com.activelearninglabs.domain.Lab;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the Lab entity.
 */
@SuppressWarnings("unused")
@Repository
public interface LabRepository extends JpaRepository<Lab, Long> {

}
