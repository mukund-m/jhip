package com.activelearninglabs.repository;
import com.activelearninglabs.domain.ActionTopicMapping;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;


/**
 * Spring Data  repository for the ActionTopicMapping entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ActionTopicMappingRepository extends JpaRepository<ActionTopicMapping, Long> {

}
