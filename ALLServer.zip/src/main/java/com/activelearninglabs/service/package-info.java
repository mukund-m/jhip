/**
 * Service layer beans.
 */
package com.activelearninglabs.service;
