package com.activelearninglabs.service;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.activelearninglabs.domain.ALLUser;
import com.activelearninglabs.domain.Authority;
import com.activelearninglabs.domain.User;
import com.activelearninglabs.firebase.FirebaseConfig;
import com.activelearninglabs.repository.ALLUserRepository;
import com.activelearninglabs.repository.AuthorityRepository;
import com.activelearninglabs.repository.UserRepository;
import com.activelearninglabs.security.AuthoritiesConstants;
import com.activelearninglabs.service.dto.UserDTO;
import com.activelearninglabs.service.util.RandomUtil;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.UserRecord;
import com.google.firebase.auth.UserRecord.CreateRequest;

@Service
public class StudentService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
    private AuthorityRepository authorityRepository;
	@Autowired
	private ALLUserRepository allUserRepository;
	
	@Transactional
	public void createUser(ALLUser user) throws FirebaseAuthException {
		UserRecord userRecord = this.createFirebaseUser(user.getEmail(), UUID.randomUUID().toString(), user.getFirstName() + " " + user.getLastName());
		UserDTO userDTO = new UserDTO();
		userDTO.setEmail(user.getEmail());
		userDTO.setFirstName(user.getFirstName());
		userDTO.setLastName(user.getLastName());
		userDTO.setLogin(user.getEmail());
		User user1 = this.registerUser(userDTO, userRecord.getUid());
		user.setActive(true);
		user.setClient(null);  // client of current user
		user.setClassRoom(null);  // classrrom
		user.setRole("STUDENT");
		user.setUid(userRecord.getUid());
		user.setUser(user1);
		this.allUserRepository.save(user);
		
		
		
	}
	
	private UserRecord createFirebaseUser(String email, String password, String displayName ) throws FirebaseAuthException {
		CreateRequest request = new CreateRequest()
			    .setEmail("user@example.com")
			    .setEmailVerified(true)
			    .setPassword("secretPassword")
			    .setDisplayName("John Doe")
			    .setDisabled(false);
			UserRecord userRecord = FirebaseConfig.getInstance().getAuth().createUser(request);
			return userRecord;
	}
	
	public User registerUser(UserDTO userDTO, String password) {
        userRepository.findOneByLogin(userDTO.getLogin().toLowerCase()).ifPresent(existingUser -> {
            throw new UsernameAlreadyUsedException();
        });
        userRepository.findOneByEmailIgnoreCase(userDTO.getEmail()).ifPresent(existingUser -> {
        	throw new EmailAlreadyUsedException();
        });
        User newUser = new User();
        String encryptedPassword = passwordEncoder.encode(password);
        newUser.setLogin(userDTO.getLogin().toLowerCase());
        // new user gets initially a generated password
        newUser.setPassword(encryptedPassword);
        newUser.setFirstName(userDTO.getFirstName());
        newUser.setLastName(userDTO.getLastName());
        newUser.setEmail(userDTO.getEmail().toLowerCase());
        newUser.setImageUrl(userDTO.getImageUrl());
        newUser.setLangKey(userDTO.getLangKey());
        // new user gets registration key
        newUser.setActivationKey(RandomUtil.generateActivationKey());
        Set<Authority> authorities = new HashSet<>();
        authorityRepository.findById(AuthoritiesConstants.STUDENT).ifPresent(authorities::add);
        newUser.setAuthorities(authorities);
        userRepository.save(newUser);
        return newUser;
    }
}
