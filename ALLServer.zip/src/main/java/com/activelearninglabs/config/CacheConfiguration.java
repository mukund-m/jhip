package com.activelearninglabs.config;

import java.time.Duration;

import org.ehcache.config.builders.*;
import org.ehcache.jsr107.Eh107Configuration;

import org.hibernate.cache.jcache.ConfigSettings;
import io.github.jhipster.config.JHipsterProperties;

import org.springframework.boot.autoconfigure.cache.JCacheManagerCustomizer;
import org.springframework.boot.autoconfigure.orm.jpa.HibernatePropertiesCustomizer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.*;

@Configuration
@EnableCaching
public class CacheConfiguration {

    private final javax.cache.configuration.Configuration<Object, Object> jcacheConfiguration;

    public CacheConfiguration(JHipsterProperties jHipsterProperties) {
        JHipsterProperties.Cache.Ehcache ehcache = jHipsterProperties.getCache().getEhcache();

        jcacheConfiguration = Eh107Configuration.fromEhcacheCacheConfiguration(
            CacheConfigurationBuilder.newCacheConfigurationBuilder(Object.class, Object.class,
                ResourcePoolsBuilder.heap(ehcache.getMaxEntries()))
                .withExpiry(ExpiryPolicyBuilder.timeToLiveExpiration(Duration.ofSeconds(ehcache.getTimeToLiveSeconds())))
                .build());
    }

    @Bean
    public HibernatePropertiesCustomizer hibernatePropertiesCustomizer(javax.cache.CacheManager cacheManager) {
        return hibernateProperties -> hibernateProperties.put(ConfigSettings.CACHE_MANAGER, cacheManager);
    }

    @Bean
    public JCacheManagerCustomizer cacheManagerCustomizer() {
        return cm -> {
            createCache(cm, com.activelearninglabs.repository.UserRepository.USERS_BY_LOGIN_CACHE);
            createCache(cm, com.activelearninglabs.repository.UserRepository.USERS_BY_EMAIL_CACHE);
            createCache(cm, com.activelearninglabs.domain.User.class.getName());
            createCache(cm, com.activelearninglabs.domain.Authority.class.getName());
            createCache(cm, com.activelearninglabs.domain.User.class.getName() + ".authorities");
            createCache(cm, com.activelearninglabs.domain.EntityAuditEvent.class.getName());
            createCache(cm, com.activelearninglabs.domain.Client.class.getName());
            createCache(cm, com.activelearninglabs.domain.Client.class.getName() + ".users");
            createCache(cm, com.activelearninglabs.domain.Client.class.getName() + ".classRooms");
            createCache(cm, com.activelearninglabs.domain.MasterLab.class.getName());
            createCache(cm, com.activelearninglabs.domain.MasterLab.class.getName() + ".labs");
            createCache(cm, com.activelearninglabs.domain.ActionTopicMapping.class.getName());
            createCache(cm, com.activelearninglabs.domain.Topic.class.getName());
            createCache(cm, com.activelearninglabs.domain.Topic.class.getName() + ".workbookUploads");
            createCache(cm, com.activelearninglabs.domain.ALLUser.class.getName());
            createCache(cm, com.activelearninglabs.domain.ALLUser.class.getName() + ".singleUserLabs");
            createCache(cm, com.activelearninglabs.domain.WorkbookUpload.class.getName());
            createCache(cm, com.activelearninglabs.domain.ClassRoom.class.getName());
            createCache(cm, com.activelearninglabs.domain.ClassRoom.class.getName() + ".labs");
            createCache(cm, com.activelearninglabs.domain.ClassRoom.class.getName() + ".users");
            createCache(cm, com.activelearninglabs.domain.ClassRoom.class.getName() + ".notifications");
            createCache(cm, com.activelearninglabs.domain.ClassRoom.class.getName() + ".teams");
            createCache(cm, com.activelearninglabs.domain.Team.class.getName());
            createCache(cm, com.activelearninglabs.domain.Team.class.getName() + ".students");
            createCache(cm, com.activelearninglabs.domain.Lab.class.getName());
            createCache(cm, com.activelearninglabs.domain.Lab.class.getName() + ".notifications");
            createCache(cm, com.activelearninglabs.domain.Lab.class.getName() + ".workerAssignments");
            createCache(cm, com.activelearninglabs.domain.Lab.class.getName() + ".stageSubmissions");
            createCache(cm, com.activelearninglabs.domain.Lab.class.getName() + ".teacherAlerts");
            createCache(cm, com.activelearninglabs.domain.Notification.class.getName());
            createCache(cm, com.activelearninglabs.domain.Audit.class.getName());
            createCache(cm, com.activelearninglabs.domain.WorkerAssignment.class.getName());
            createCache(cm, com.activelearninglabs.domain.StageSubmission.class.getName());
            createCache(cm, com.activelearninglabs.domain.TeacherAlert.class.getName());
            // jhipster-needle-ehcache-add-entry
        };
    }

    private void createCache(javax.cache.CacheManager cm, String cacheName) {
        javax.cache.Cache<Object, Object> cache = cm.getCache(cacheName);
        if (cache != null) {
            cm.destroyCache(cacheName);
        }
        cm.createCache(cacheName, jcacheConfiguration);
    }
}
